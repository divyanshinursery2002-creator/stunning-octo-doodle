import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Product,
  ServicePackage,
  LandscapingProject,
  SiteSettings,
  Testimonial,
  Enquiry,
  Order,
  OrderItem,
  ProductCategory,
} from '../types';
import {
  initialProducts,
  initialServicePackages,
  initialProjects,
  initialSiteSettings,
  initialTestimonials,
} from '../data/initialData';

interface AppContextType {
  products: Product[];
  services: ServicePackage[];
  projects: LandscapingProject[];
  settings: SiteSettings;
  testimonials: Testimonial[];
  enquiries: Enquiry[];
  orders: Order[];
  currentView: 'home' | 'plants' | 'maintenance' | 'landscaping' | 'pots' | 'contact' | 'admin';
  setCurrentView: (view: 'home' | 'plants' | 'maintenance' | 'landscaping' | 'pots' | 'contact' | 'admin') => void;
  selectedCategory: ProductCategory | 'All';
  setSelectedCategory: (category: ProductCategory | 'All') => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  // Cart
  cart: OrderItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  // Quick View Modal
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
  // Booking / Enquiry Modal
  serviceBookingModal: { isOpen: boolean; serviceTitle?: string; initialType?: string };
  setServiceBookingModal: (modal: { isOpen: boolean; serviceTitle?: string; initialType?: string }) => void;
  // Admin
  isAdminLoggedIn: boolean;
  setIsAdminLoggedIn: (val: boolean) => void;
  // Actions
  addProduct: (product: Omit<Product, 'id'>) => Promise<Product>;
  updateProduct: (id: string, updates: Partial<Product>) => Promise<Product>;
  deleteProduct: (id: string) => Promise<void>;
  addProject: (project: Omit<LandscapingProject, 'id'>) => Promise<LandscapingProject>;
  updateProject: (id: string, updates: Partial<LandscapingProject>) => Promise<LandscapingProject>;
  deleteProject: (id: string) => Promise<void>;
  updateService: (id: string, updates: Partial<ServicePackage>) => Promise<ServicePackage>;
  addService: (service: Omit<ServicePackage, 'id'>) => Promise<ServicePackage>;
  addEnquiry: (enquiry: Omit<Enquiry, 'id' | 'createdAt' | 'status'>) => Promise<void>;
  updateEnquiryStatus: (id: string, status: Enquiry['status']) => Promise<void>;
  placeOrder: (order: Omit<Order, 'id' | 'createdAt' | 'status'>) => Promise<Order>;
  updateOrderStatus: (id: string, status: Order['status']) => Promise<void>;
  updateSettings: (newSettings: Partial<SiteSettings>) => Promise<void>;
  uploadImage: (file: File) => Promise<string>;
  openWhatsAppChat: (customText?: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('divyanshi_products');
    return saved ? JSON.parse(saved) : initialProducts;
  });

  const [services, setServices] = useState<ServicePackage[]>(() => {
    const saved = localStorage.getItem('divyanshi_services');
    return saved ? JSON.parse(saved) : initialServicePackages;
  });

  const [projects, setProjects] = useState<LandscapingProject[]>(() => {
    const saved = localStorage.getItem('divyanshi_projects');
    return saved ? JSON.parse(saved) : initialProjects;
  });

  const [settings, setSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem('divyanshi_settings');
    return saved ? JSON.parse(saved) : initialSiteSettings;
  });

  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => {
    const saved = localStorage.getItem('divyanshi_testimonials');
    return saved ? JSON.parse(saved) : initialTestimonials;
  });

  const [enquiries, setEnquiries] = useState<Enquiry[]>(() => {
    const saved = localStorage.getItem('divyanshi_enquiries');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('divyanshi_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [cart, setCart] = useState<OrderItem[]>(() => {
    const saved = localStorage.getItem('divyanshi_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentView, setCurrentView] = useState<'home' | 'plants' | 'maintenance' | 'landscaping' | 'pots' | 'contact' | 'admin'>('home');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [serviceBookingModal, setServiceBookingModal] = useState<{ isOpen: boolean; serviceTitle?: string; initialType?: string }>({
    isOpen: false,
  });
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('divyanshi_admin_logged_in') === 'true';
  });

  // Fetch live state from backend API if available
  useEffect(() => {
    fetch('/api/data')
      .then((res) => {
        if (res.ok) return res.json();
        throw new Error('API not available');
      })
      .then((data) => {
        if (data.products && data.products.length > 0) setProducts(data.products);
        if (data.services) setServices(data.services);
        if (data.projects) setProjects(data.projects);
        if (data.settings) setSettings(data.settings);
        if (data.testimonials) setTestimonials(data.testimonials);
        if (data.enquiries) setEnquiries(data.enquiries);
        if (data.orders) setOrders(data.orders);
      })
      .catch((_err) => {
        // Fallback to local state smoothly
      });
  }, []);

  // Save changes locally
  useEffect(() => {
    localStorage.setItem('divyanshi_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('divyanshi_services', JSON.stringify(services));
  }, [services]);

  useEffect(() => {
    localStorage.setItem('divyanshi_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('divyanshi_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('divyanshi_enquiries', JSON.stringify(enquiries));
  }, [enquiries]);

  useEffect(() => {
    localStorage.setItem('divyanshi_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('divyanshi_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('divyanshi_admin_logged_in', isAdminLoggedIn ? 'true' : 'false');
  }, [isAdminLoggedIn]);

  // Cart operations
  const addToCart = (product: Product, quantity = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.productId === product.id);
      if (existing) {
        return prev.map((item) =>
          item.productId === product.id ? { ...item, quantity: item.quantity + quantity } : item
        );
      }
      return [
        ...prev,
        {
          productId: product.id,
          name: product.name,
          price: product.price,
          quantity,
          image: product.image,
        },
      ];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.productId !== productId));
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.productId === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // WhatsApp helper
  const openWhatsAppChat = (customText?: string) => {
    const rawNumber = settings.whatsapp.replace(/[^0-9]/g, '');
    const phoneWithCode = rawNumber.length === 10 ? `91${rawNumber}` : rawNumber;
    const defaultMsg = `Hello Divyanshi Nursery! I am interested in your plants and landscaping services. Could you please share more details?`;
    const message = encodeURIComponent(customText || defaultMsg);
    window.open(`https://wa.me/${phoneWithCode}?text=${message}`, '_blank');
  };

  // Direct Image Upload helper (supports base64 and server persistence)
  const uploadImage = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        try {
          const res = await fetch('/api/upload', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ imageBase64: base64Data, filename: file.name }),
          });
          if (res.ok) {
            const result = await res.json();
            resolve(result.url);
          } else {
            // Fallback directly to base64 data URL
            resolve(base64Data);
          }
        } catch (e) {
          // If server upload fails, base64 data works everywhere
          resolve(base64Data);
        }
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    });
  };

  // Product CRUD
  const addProduct = async (productData: Omit<Product, 'id'>): Promise<Product> => {
    const newProduct: Product = {
      ...productData,
      id: `prod-${Date.now()}`,
    };
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProduct),
      });
      if (res.ok) {
        const created = await res.json();
        setProducts((prev) => [created, ...prev]);
        return created;
      }
    } catch (_e) {}
    setProducts((prev) => [newProduct, ...prev]);
    return newProduct;
  };

  const updateProduct = async (id: string, updates: Partial<Product>): Promise<Product> => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        const updated = await res.json();
        setProducts((prev) => prev.map((p) => (p.id === id ? updated : p)));
        return updated;
      }
    } catch (_e) {}

    let updatedProd: Product = {} as Product;
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          updatedProd = { ...p, ...updates };
          return updatedProd;
        }
        return p;
      })
    );
    return updatedProd;
  };

  const deleteProduct = async (id: string): Promise<void> => {
    try {
      await fetch(`/api/products/${id}`, { method: 'DELETE' });
    } catch (_e) {}
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  // Projects CRUD
  const addProject = async (projectData: Omit<LandscapingProject, 'id'>): Promise<LandscapingProject> => {
    const newProj: LandscapingProject = {
      ...projectData,
      id: `proj-${Date.now()}`,
    };
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProj),
      });
      if (res.ok) {
        const created = await res.json();
        setProjects((prev) => [created, ...prev]);
        return created;
      }
    } catch (_e) {}
    setProjects((prev) => [newProj, ...prev]);
    return newProj;
  };

  const updateProject = async (id: string, updates: Partial<LandscapingProject>): Promise<LandscapingProject> => {
    try {
      const res = await fetch(`/api/projects/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        const updated = await res.json();
        setProjects((prev) => prev.map((p) => (p.id === id ? updated : p)));
        return updated;
      }
    } catch (_e) {}

    let updatedProj: LandscapingProject = {} as LandscapingProject;
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          updatedProj = { ...p, ...updates };
          return updatedProj;
        }
        return p;
      })
    );
    return updatedProj;
  };

  const deleteProject = async (id: string): Promise<void> => {
    try {
      await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    } catch (_e) {}
    setProjects((prev) => prev.filter((p) => p.id !== id));
  };

  // Services CRUD
  const addService = async (serviceData: Omit<ServicePackage, 'id'>): Promise<ServicePackage> => {
    const newServ: ServicePackage = {
      ...serviceData,
      id: `serv-${Date.now()}`,
    };
    try {
      const res = await fetch('/api/services', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newServ),
      });
      if (res.ok) {
        const created = await res.json();
        setServices((prev) => [...prev, created]);
        return created;
      }
    } catch (_e) {}
    setServices((prev) => [...prev, newServ]);
    return newServ;
  };

  const updateService = async (id: string, updates: Partial<ServicePackage>): Promise<ServicePackage> => {
    try {
      const res = await fetch(`/api/services/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      if (res.ok) {
        const updated = await res.json();
        setServices((prev) => prev.map((s) => (s.id === id ? updated : s)));
        return updated;
      }
    } catch (_e) {}

    let updatedServ: ServicePackage = {} as ServicePackage;
    setServices((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          updatedServ = { ...s, ...updates };
          return updatedServ;
        }
        return s;
      })
    );
    return updatedServ;
  };

  // Enquiries & Orders
  const addEnquiry = async (enquiryData: Omit<Enquiry, 'id' | 'createdAt' | 'status'>): Promise<void> => {
    const newEnq: Enquiry = {
      ...enquiryData,
      id: `enq-${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'New',
    };
    try {
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEnq),
      });
      if (res.ok) {
        const created = await res.json();
        setEnquiries((prev) => [created, ...prev]);
        return;
      }
    } catch (_e) {}
    setEnquiries((prev) => [newEnq, ...prev]);
  };

  const updateEnquiryStatus = async (id: string, status: Enquiry['status']): Promise<void> => {
    try {
      await fetch(`/api/enquiries/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
    } catch (_e) {}
    setEnquiries((prev) => prev.map((e) => (e.id === id ? { ...e, status } : e)));
  };

  const placeOrder = async (orderData: Omit<Order, 'id' | 'createdAt' | 'status'>): Promise<Order> => {
    const newOrder: Order = {
      ...orderData,
      id: `ord-${Date.now()}`,
      createdAt: new Date().toISOString(),
      status: 'Pending',
    };
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrder),
      });
      if (res.ok) {
        const created = await res.json();
        setOrders((prev) => [created, ...prev]);
        clearCart();
        return created;
      }
    } catch (_e) {}
    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const updateOrderStatus = async (id: string, status: Order['status']): Promise<void> => {
    try {
      await fetch(`/api/orders/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
    } catch (_e) {}
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
  };

  const updateSettings = async (newSettings: Partial<SiteSettings>): Promise<void> => {
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
      if (res.ok) {
        const updated = await res.json();
        setSettings(updated);
        return;
      }
    } catch (_e) {}
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  return (
    <AppContext.Provider
      value={{
        products,
        services,
        projects,
        settings,
        testimonials,
        enquiries,
        orders,
        currentView,
        setCurrentView,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartTotal,
        cartCount,
        isCartOpen,
        setIsCartOpen,
        quickViewProduct,
        setQuickViewProduct,
        serviceBookingModal,
        setServiceBookingModal,
        isAdminLoggedIn,
        setIsAdminLoggedIn,
        addProduct,
        updateProduct,
        deleteProduct,
        addProject,
        updateProject,
        deleteProject,
        updateService,
        addService,
        addEnquiry,
        updateEnquiryStatus,
        placeOrder,
        updateOrderStatus,
        updateSettings,
        uploadImage,
        openWhatsAppChat,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

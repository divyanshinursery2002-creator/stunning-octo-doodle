import React, { useState, useRef, useEffect } from 'react';
import { Upload, X, Check, Image as ImageIcon, Sparkles, Camera, RefreshCw } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface ImageUploaderProps {
  label: string;
  currentImage?: string;
  onImageSelected: (url: string) => void;
  aspectRatioLabel?: string;
  isLogo?: boolean;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  label,
  currentImage,
  onImageSelected,
  aspectRatioLabel = '4:3 or 16:9',
  isLogo = false,
}) => {
  const { uploadImage } = useApp();
  const [preview, setPreview] = useState<string>(currentImage || '');
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [showPresetPicker, setShowPresetPicker] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Synchronize internal state whenever currentImage prop changes externally
  useEffect(() => {
    setPreview(currentImage || '');
  }, [currentImage]);

  // Curated Plant Presets
  const plantPresets = [
    { name: 'Nursery Greenhouse', url: '/src/assets/images/hero_botanical_nursery_1793198790963.jpg' },
    { name: 'Fiddle Leaf Fig', url: '/src/assets/images/plant_fiddle_leaf_fig_1793198788666.jpg' },
    { name: 'Monstera Deliciosa', url: '/src/assets/images/plant_monstera_deliciosa_1793198788974.jpg' },
    { name: 'Snake Plant', url: '/src/assets/images/plant_snake_plant_1793198790249.jpg' },
    { name: 'Terrace Garden Landscape', url: '/src/assets/images/landscaping_terrace_garden_1793198790764.jpg' },
    { name: 'Designer Ceramic Pots', url: '/src/assets/images/pots_designer_planters_1793198790397.jpg' },
    { name: 'Peace Lily White Bloom', url: 'https://images.unsplash.com/photo-1593691509543-c55fb32e7355?auto=format&fit=crop&w=800&q=80' },
    { name: 'Areca Palm Greenery', url: 'https://images.unsplash.com/photo-1614594975525-e45190c55d0b?auto=format&fit=crop&w=800&q=80' },
    { name: 'Mini Jade Bonsai', url: 'https://images.unsplash.com/photo-1509423350716-97f9360b4e09?auto=format&fit=crop&w=800&q=80' },
  ];

  // Curated Nursery Logo Presets
  const logoPresets = [
    {
      name: 'Forest Leaf Emblem (Default SVG)',
      url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="%231b382b"><circle cx="50" cy="50" r="48" fill="%231b382b"/><path d="M50 18 C30 18 18 36 18 50 C18 64 30 82 50 82 C70 82 82 64 82 50 C82 36 70 18 50 18 Z M50 25 C66 25 75 40 75 50 C75 60 66 75 50 75 C34 75 25 60 25 50 C25 40 34 25 50 25 Z" fill="%23d2e5d8"/><path d="M50 25 L50 75" stroke="%23d2e5d8" stroke-width="4"/><path d="M50 40 L65 32 M50 50 L68 45 M50 60 L65 58 M50 40 L35 32 M50 50 L32 45 M50 60 L35 58" stroke="%23d2e5d8" stroke-width="3"/></svg>',
    },
    {
      name: 'Golden Botanical Branch Logo',
      url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="%230d2217"><circle cx="50" cy="50" r="48" fill="%230d2217"/><circle cx="50" cy="50" r="43" fill="none" stroke="%23d4af37" stroke-width="2"/><path d="M50 25 Q55 45 50 75" stroke="%23d4af37" stroke-width="3" fill="none"/><path d="M50 35 C60 30 65 38 52 42 C40 38 42 30 50 35 Z M51 50 C62 46 66 54 52 57 C40 54 41 46 51 50 Z M50 62 C60 58 64 66 51 68 C41 66 42 58 50 62 Z" fill="%23d4af37"/></svg>',
    },
    {
      name: 'Modern Minimal Monstera Emblem',
      url: 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="50" cy="50" r="48" fill="%232d5a3f"/><path d="M50 22 C34 22 22 34 22 52 C22 70 36 78 50 78 C64 78 78 70 78 52 C78 34 66 22 50 22 Z" fill="%23ffffff"/><path d="M50 30 L50 72" stroke="%232d5a3f" stroke-width="3"/><circle cx="40" cy="42" r="4" fill="%232d5a3f"/><circle cx="60" cy="42" r="4" fill="%232d5a3f"/><circle cx="36" cy="56" r="4" fill="%232d5a3f"/><circle cx="64" cy="56" r="4" fill="%232d5a3f"/></svg>',
    },
  ];

  const presets = isLogo ? logoPresets : plantPresets;

  const handleFile = async (file: File) => {
    if (!file.type.match(/image\/(jpeg|png|webp|svg\+xml|svg)/)) {
      alert('Please select a JPG, PNG, WebP, or SVG image.');
      return;
    }

    setUploading(true);
    try {
      const url = await uploadImage(file);
      setPreview(url);
      onImageSelected(url);
    } catch (err) {
      alert('Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleSelectPreset = (url: string) => {
    setPreview(url);
    onImageSelected(url);
    setShowPresetPicker(false);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs">
        <label className="font-semibold text-[#14261d] flex items-center gap-1.5">
          <span>{label}</span>
          {uploading && (
            <span className="text-[11px] text-[#2d5a3f] font-normal flex items-center gap-1">
              <RefreshCw className="w-3 h-3 animate-spin" /> Uploading...
            </span>
          )}
        </label>
        <span className="text-[11px] text-[#6b8577]">Recommended: {aspectRatioLabel}</span>
      </div>

      {preview ? (
        <div className="space-y-2">
          {/* Main Preview Container */}
          <div
            className={`relative group rounded-xl overflow-hidden border border-[#d6cfc0] bg-[#faf9f6] ${
              isLogo ? 'max-w-[240px] aspect-square mx-auto p-3 flex items-center justify-center' : 'aspect-[16/10]'
            }`}
          >
            <img
              src={preview}
              alt="Preview"
              referrerPolicy="no-referrer"
              className={`object-contain transition-transform duration-300 group-hover:scale-102 ${
                isLogo ? 'max-h-full max-w-full rounded-full border border-stone-200 shadow-sm' : 'w-full h-full object-cover'
              }`}
            />

            {/* Quick Actions Hover Scrim */}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 p-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-3 py-1.5 bg-white text-[#1b382b] rounded-lg text-xs font-semibold hover:bg-[#ede8df] transition-colors shadow-sm cursor-pointer"
              >
                Change Photo
              </button>
              <button
                type="button"
                onClick={() => setShowPresetPicker(true)}
                className="px-3 py-1.5 bg-[#1b382b] text-white rounded-lg text-xs font-semibold hover:bg-[#254d3b] transition-colors shadow-sm cursor-pointer"
              >
                Pick Preset
              </button>
              <button
                type="button"
                onClick={() => {
                  setPreview('');
                  onImageSelected('');
                }}
                className="p-1.5 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors shadow-sm cursor-pointer"
                title="Remove image"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick status bar below preview */}
          <div className="flex items-center justify-between text-[11px] text-[#5e7d6b]">
            <span className="flex items-center gap-1 text-emerald-700 font-medium">
              <Check className="w-3.5 h-3.5" /> High-Resolution Photo Ready
            </span>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="text-[#1b382b] hover:underline font-semibold"
            >
              Upload another
            </button>
          </div>
        </div>
      ) : (
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-colors ${
            dragActive
              ? 'border-[#1b382b] bg-[#eef5f0]'
              : 'border-[#d6cfc0] hover:border-[#1b382b] bg-[#faf9f6]'
          }`}
        >
          <div className="w-11 h-11 rounded-full bg-[#ede8df] text-[#1b382b] flex items-center justify-center mx-auto mb-2">
            <Upload className="w-5 h-5" />
          </div>
          <p className="text-xs font-bold text-[#14261d]">
            {uploading ? 'Processing & Optimizing Image...' : 'Click to Upload or Drag & Drop'}
          </p>
          <p className="text-[11px] text-[#6e8a7b] mt-0.5">
            Directly select from camera or gallery (JPG, PNG, WebP up to 15MB)
          </p>

          <div className="mt-3 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setShowPresetPicker(true);
              }}
              className="inline-flex items-center gap-1 text-[11px] text-[#2d5a3f] font-semibold hover:underline bg-white px-2.5 py-1 rounded-md border border-[#ded8cb]"
            >
              <Sparkles className="w-3 h-3" />
              <span>{isLogo ? 'Choose Logo Preset' : 'Choose from HD Plant Library'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleInputChange}
        className="hidden"
      />

      {/* Preset Library Modal */}
      {showPresetPicker && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-[#ded8cb]">
            <div className="flex items-center justify-between pb-3 border-b border-[#ded8cb] mb-4">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-[#1b382b]" />
                <h4 className="font-serif text-base font-bold text-[#14261d]">
                  {isLogo ? 'Select Nursery Logo Preset' : 'Select from Full HD Botanical Library'}
                </h4>
              </div>
              <button
                type="button"
                onClick={() => setShowPresetPicker(false)}
                className="p-1 text-[#6b8577] hover:text-[#14261d]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className={`grid gap-3 max-h-[60vh] overflow-y-auto p-1 ${isLogo ? 'grid-cols-1 sm:grid-cols-3' : 'grid-cols-2 sm:grid-cols-3'}`}>
              {presets.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => handleSelectPreset(item.url)}
                  className="group relative rounded-xl overflow-hidden border border-[#ded8cb] cursor-pointer hover:border-[#1b382b] bg-[#faf9f6] flex flex-col items-center justify-between p-2 hover:shadow-md transition-all"
                >
                  <div className={`w-full overflow-hidden flex items-center justify-center ${isLogo ? 'h-24 p-2' : 'aspect-square'}`}>
                    <img
                      src={item.url}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className={`object-contain ${isLogo ? 'w-20 h-20 rounded-full' : 'w-full h-full object-cover transition-transform group-hover:scale-105'}`}
                    />
                  </div>
                  <span className="text-[11px] font-semibold text-[#14261d] text-center mt-2 truncate w-full">
                    {item.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

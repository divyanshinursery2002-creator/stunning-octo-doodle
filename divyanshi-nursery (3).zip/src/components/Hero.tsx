import React from 'react';
import { useApp } from '../context/AppContext';
import { Search, ArrowRight, PhoneCall, Sparkles, Sprout, ShieldCheck, Truck } from 'lucide-react';

export const Hero: React.FC = () => {
  const {
    settings,
    setCurrentView,
    searchQuery,
    setSearchQuery,
    setSelectedCategory,
  } = useApp();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setCurrentView('plants');
    }
  };

  return (
    <section className="relative overflow-hidden bg-[#faf9f6]">
      {/* Hero Visual Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-14 lg:pt-12 lg:pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Headlines & Actions */}
          <div className="lg:col-span-7 space-y-6">
            {/* Quiet Editorial Kicker (No Pill Enclosures) */}
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
              <Sprout className="w-4 h-4 text-[#2d5a3f]" />
              <span>Premium Botanical Nursery & Landscape Architects</span>
            </div>

            {/* Main Headline (Balanced Typography) */}
            <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl font-bold text-[#14261d] tracking-tight leading-[1.12] text-balance">
              {settings.heroHeadline}
            </h1>

            {/* Supporting Text */}
            <p className="text-base sm:text-lg text-[#3f574a] leading-relaxed max-w-xl">
              {settings.heroSubtitle}
            </p>

            {/* Search Bar for Plants & Products */}
            <form onSubmit={handleSearchSubmit} className="max-w-xl">
              <div className="relative flex items-center shadow-sm">
                <Search className="w-5 h-5 text-[#5e7d6b] absolute left-3.5 pointer-events-none" />
                <input
                  type="text"
                  placeholder="Search fiddle leaf, monstera, ceramic pots, or grass..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-28 py-3.5 bg-white border border-[#d6cfc0] rounded-xl text-sm text-[#1b382b] placeholder-[#7d9386] focus:outline-none focus:ring-2 focus:ring-[#2d5a3f] focus:border-transparent transition-all"
                />
                <button
                  type="submit"
                  className="absolute right-1.5 px-4 py-2 bg-[#1b382b] hover:bg-[#264b3a] text-white text-xs font-medium rounded-lg transition-colors"
                >
                  Search
                </button>
              </div>
            </form>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setCurrentView('plants');
                }}
                className="px-6 py-3.5 bg-[#1b382b] hover:bg-[#264b3a] text-white text-sm font-semibold rounded-xl transition-all shadow-sm hover:shadow flex items-center gap-2 group cursor-pointer"
              >
                <span>Explore Plants</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </button>

              <button
                onClick={() => setCurrentView('contact')}
                className="px-6 py-3.5 bg-[#ede8df] hover:bg-[#e2dcce] text-[#1b382b] text-sm font-semibold rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
              >
                <PhoneCall className="w-4 h-4 text-[#2d5a3f]" />
                <span>Contact Us</span>
              </button>
            </div>

            {/* Quick Category Jump Links (Clean unboxed inline tags) */}
            <div className="pt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-[#52705f]">
              <span className="font-semibold text-[#1b382b]">Popular:</span>
              <button
                onClick={() => {
                  setSelectedCategory('Indoor Plants');
                  setCurrentView('plants');
                }}
                className="hover:text-[#1b382b] hover:underline"
              >
                Indoor Foliage
              </button>
              <span aria-hidden="true">·</span>
              <button
                onClick={() => {
                  setSelectedCategory('Air-Purifying Plants');
                  setCurrentView('plants');
                }}
                className="hover:text-[#1b382b] hover:underline"
              >
                Air Purifiers
              </button>
              <span aria-hidden="true">·</span>
              <button
                onClick={() => setCurrentView('pots')}
                className="hover:text-[#1b382b] hover:underline"
              >
                Ceramic Pots
              </button>
              <span aria-hidden="true">·</span>
              <button
                onClick={() => setCurrentView('landscaping')}
                className="hover:text-[#1b382b] hover:underline"
              >
                Terrace Gardens
              </button>
            </div>
          </div>

          {/* Right Column: High-Resolution Greenhouse Photo */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-[#ded8cb] bg-[#e8e4da] aspect-[4/3] lg:aspect-[5/4] group">
              <img
                src={settings.heroImage}
                alt="Divyanshi Nursery luxury botanical greenhouse"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                onError={(e) => {
                  // Fallback container
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              {/* Subtle aesthetic gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />

              {/* Verified Quality Floating Badge */}
              <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md p-3.5 rounded-xl border border-white/50 text-xs text-[#1c2e24] shadow-md flex items-center justify-between">
                <div>
                  <p className="font-bold text-[#14261d]">Verified Botanical Health</p>
                  <p className="text-[11px] text-[#5e7d6b]">Nurtured with 100% natural organic compost</p>
                </div>
                <div className="w-8 h-8 rounded-full bg-[#1b382b] text-emerald-300 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* 4-Item Proof & Trust Strip (Directly Adjacent Below Hero) */}
        <div className="mt-12 pt-8 border-t border-[#e2dcd0] grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center shrink-0">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#14261d] tabular-nums">500+ Varieties</p>
              <p className="text-xs text-[#5e7d6b]">Indoor, outdoor & exotic species</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#14261d] tabular-nums">15+ Years Trust</p>
              <p className="text-xs text-[#5e7d6b]">Certified expert horticulturists</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#14261d]">Safe Home Delivery</p>
              <p className="text-xs text-[#5e7d6b]">Potted securely with no root disturbance</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-lg bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <p className="text-sm font-bold text-[#14261d] tabular-nums">Turnkey Landscapes</p>
              <p className="text-xs text-[#5e7d6b]">From terrace roofs to luxury villas</p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

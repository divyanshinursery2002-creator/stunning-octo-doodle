import React from 'react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';
import { ShoppingBag, Eye, MessageCircle, Sun, Droplets, CheckCircle, XCircle } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, setQuickViewProduct, openWhatsAppChat } = useApp();

  const handleWhatsAppEnquiry = (e: React.MouseEvent) => {
    e.stopPropagation();
    const message = `Hello Divyanshi Nursery! I want to enquire about "${product.name}" (Price: ₹${product.price}). Is it in stock and available for delivery?`;
    openWhatsAppChat(message);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  return (
    <div
      onClick={() => setQuickViewProduct(product)}
      className="group bg-white rounded-2xl border border-[#e5dfd3] overflow-hidden hover:border-[#1b382b]/40 hover:shadow-lg transition-all duration-300 flex flex-col cursor-pointer"
    >
      {/* Product Image Slot (65-75% visual dominance) */}
      <div className="relative aspect-[4/3] bg-[#f5f2eb] overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          onError={(e) => {
            // Elegant botanical SVG fallback
            const target = e.target as HTMLImageElement;
            target.src = 'https://images.unsplash.com/photo-1545241047-6083a3684587?auto=format&fit=crop&w=800&q=80';
          }}
        />

        {/* Quick View Hover Button */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
          <span className="px-3 py-1.5 bg-white/90 backdrop-blur-sm text-xs font-semibold text-[#1b382b] rounded-lg shadow-sm flex items-center gap-1.5">
            <Eye className="w-3.5 h-3.5" />
            Quick View
          </span>
        </div>

        {/* Stock Status Tag (Clean Single-Line Text Tag) */}
        <div className="absolute top-3 left-3">
          {product.inStock ? (
            <span className="px-2.5 py-1 bg-white/90 backdrop-blur-sm text-[#235338] text-[11px] font-semibold rounded-md border border-white/60 flex items-center gap-1">
              <CheckCircle className="w-3 h-3 text-emerald-600" />
              In Stock
            </span>
          ) : (
            <span className="px-2.5 py-1 bg-red-50 text-red-700 text-[11px] font-semibold rounded-md border border-red-200 flex items-center gap-1">
              <XCircle className="w-3 h-3 text-red-600" />
              Out of Stock
            </span>
          )}
        </div>

        {/* WhatsApp Quick Inquire Icon */}
        <button
          onClick={handleWhatsAppEnquiry}
          title="Inquire on WhatsApp"
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm text-emerald-700 hover:bg-emerald-600 hover:text-white transition-colors flex items-center justify-center shadow-sm"
        >
          <MessageCircle className="w-4 h-4" />
        </button>
      </div>

      {/* Product Content Body */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Category & Botanical Metadata (Unboxed text with dots) */}
          <div className="flex items-center gap-1.5 text-xs text-[#5f7a6b] mb-1">
            <span>{product.category}</span>
            {product.botanicalName && (
              <>
                <span aria-hidden="true">·</span>
                <span className="italic truncate">{product.botanicalName}</span>
              </>
            )}
          </div>

          {/* Product Title */}
          <h3 className="font-serif text-base sm:text-lg font-bold text-[#152a1f] group-hover:text-[#2d5a3f] transition-colors leading-snug line-clamp-1">
            {product.name}
          </h3>

          {/* Short Description */}
          <p className="text-xs text-[#526a5c] mt-1.5 line-clamp-2 leading-relaxed">
            {product.description}
          </p>

          {/* Quick Care Snapshot */}
          {product.careInstructions && (
            <div className="mt-3 pt-2.5 border-t border-[#f0ebe0] grid grid-cols-2 gap-2 text-[11px] text-[#4f6b5b]">
              <div className="flex items-center gap-1 truncate" title={product.careInstructions.sunlight}>
                <Sun className="w-3 h-3 text-amber-600 shrink-0" />
                <span className="truncate">{product.careInstructions.sunlight.split(',')[0]}</span>
              </div>
              <div className="flex items-center gap-1 truncate" title={product.careInstructions.watering}>
                <Droplets className="w-3 h-3 text-blue-600 shrink-0" />
                <span className="truncate">{product.careInstructions.watering.split(';')[0]}</span>
              </div>
            </div>
          )}
        </div>

        {/* Price & Primary Purchase Actions */}
        <div className="mt-4 pt-3 border-t border-[#ede7dc]">
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-lg sm:text-xl font-bold text-[#14261d] tabular-nums font-mono">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.discountPrice && product.discountPrice > product.price && (
              <span className="text-xs text-[#8c9e94] line-through tabular-nums font-mono">
                ₹{product.discountPrice.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleAddToCart}
              disabled={!product.inStock}
              className={`py-2 px-3 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                product.inStock
                  ? 'bg-[#ede8df] hover:bg-[#ded6c7] text-[#1b382b]'
                  : 'bg-stone-100 text-stone-400 cursor-not-allowed'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Add to Cart</span>
            </button>

            <button
              onClick={handleBuyNow}
              disabled={!product.inStock}
              className={`py-2 px-3 text-xs font-semibold rounded-lg flex items-center justify-center transition-colors cursor-pointer ${
                product.inStock
                  ? 'bg-[#1b382b] hover:bg-[#254d3b] text-white'
                  : 'bg-stone-200 text-stone-400 cursor-not-allowed'
              }`}
            >
              Buy Now
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

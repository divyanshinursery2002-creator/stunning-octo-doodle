import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Calendar, MessageCircle, CheckCircle2 } from 'lucide-react';

export const ServiceBookingModal: React.FC = () => {
  const { serviceBookingModal, setServiceBookingModal, addEnquiry, openWhatsAppChat } = useApp();

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [date, setDate] = useState('');
  const [address, setAddress] = useState('');
  const [gardenSize, setGardenSize] = useState('Medium (500 - 1500 sq ft)');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!serviceBookingModal.isOpen) return null;

  const title = serviceBookingModal.serviceTitle || 'Garden Service';

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone || !address) {
      alert('Please fill out name, phone, and site address.');
      return;
    }

    setIsSubmitting(true);
    try {
      await addEnquiry({
        customerName,
        phone,
        serviceType: `Service Booking: ${title}`,
        location: address,
        message: `Preferred Date: ${date || 'Earliest available'}\nGarden Area: ${gardenSize}\nSpecial requests: ${notes || 'None'}`,
      });
      setIsSuccess(true);
    } catch (_e) {
      alert('Could not submit booking. Please contact via WhatsApp.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWhatsAppBooking = () => {
    const text = `🌿 *Service Booking Request - Divyanshi Nursery*\nService: ${title}\nCustomer: ${customerName || 'Customer'}\nPhone: ${phone || 'Available'}\nAddress: ${address || 'Local'}\nDate: ${date || 'Flexible'}\nArea: ${gardenSize}\nNotes: ${notes || 'None'}`;
    openWhatsAppChat(text);
  };

  const handleClose = () => {
    setServiceBookingModal({ isOpen: false });
    setIsSuccess(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-[#ded8cb] my-8 p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-1.5 text-[#5e7d6b] hover:text-[#14261d] hover:bg-[#ede8df] rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-serif text-xl font-bold text-[#14261d]">
              Service Booking Received!
            </h3>
            <p className="text-xs text-[#4f6859] max-w-xs mx-auto">
              We have scheduled your request for <strong>{title}</strong>. Our horticulturist supervisor will call you to confirm the exact slot.
            </p>
            <div className="pt-3">
              <button
                onClick={handleWhatsAppBooking}
                className="w-full py-2.5 bg-[#156e3b] text-white rounded-xl text-xs font-semibold hover:bg-[#10532c] flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Confirm over WhatsApp</span>
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-[#2d5a3f] mb-1">
              <Calendar className="w-4 h-4" />
              <span>Schedule Service Visit</span>
            </div>
            <h3 className="font-serif text-xl font-bold text-[#14261d] mb-1">
              {title}
            </h3>
            <p className="text-xs text-[#526d5e] mb-6">
              Book a certified nursery horticulturist to visit and inspect your garden.
            </p>

            <form onSubmit={handleBookingSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Anand Mehta"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. 9265706952"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Preferred Date</label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Garden / Balcony Size</label>
                <select
                  value={gardenSize}
                  onChange={(e) => setGardenSize(e.target.value)}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                >
                  <option value="Balcony (Under 200 sq ft)">Balcony (Under 200 sq ft)</option>
                  <option value="Terrace / Compact Garden (200 - 800 sq ft)">Terrace / Compact Garden (200 - 800 sq ft)</option>
                  <option value="Bungalow Lawn / Large Terrace (800 - 2,500 sq ft)">Bungalow Lawn / Large Terrace (800 - 2,500 sq ft)</option>
                  <option value="Commercial / Farmhouse (2,500+ sq ft)">Commercial / Farmhouse (2,500+ sq ft)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Site Address & Landmark *</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Address where garden is situated..."
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Special Plant Symptoms or Requests</label>
                <input
                  type="text"
                  placeholder="e.g. Yellow leaves on palms, pest infestation, new soil required..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                />
              </div>

              <div className="pt-2 flex items-center gap-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-2.5 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  {isSubmitting ? 'Booking...' : 'Confirm Service Appointment'}
                </button>

                <button
                  type="button"
                  onClick={handleWhatsAppBooking}
                  className="px-3.5 py-2.5 bg-[#e8f5ec] hover:bg-[#d6eedd] text-[#165330] font-semibold rounded-xl text-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-700" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </form>
          </div>
        )}

      </div>
    </div>
  );
};

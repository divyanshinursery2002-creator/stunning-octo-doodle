import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { PotMaterial } from '../types';
import { Sparkles, MessageCircle } from 'lucide-react';

export const PotsSection: React.FC = () => {
  const { products, openWhatsAppChat } = useApp();
  const [selectedMaterial, setSelectedMaterial] = useState<PotMaterial | 'All'>('All');

  // Filter pots & planters
  const potProducts = useMemo(() => {
    return products.filter((p) => {
      const isPotCategory = p.category === 'Pots and Planters' || p.isPot;
      if (!isPotCategory) return false;
      if (selectedMaterial !== 'All' && p.potMaterial !== selectedMaterial) {
        return false;
      }
      return true;
    });
  }, [products, selectedMaterial]);

  const materials: Array<PotMaterial | 'All'> = [
    'All',
    'Ceramic',
    'Terracotta',
    'Cement',
    'Plastic',
    'Hanging',
    'Designer',
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      {/* Banner / Header */}
      <div className="relative rounded-3xl overflow-hidden bg-[#1b382b] text-white p-6 sm:p-12 mb-12 shadow-lg">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-300">
              Artisan Vessels & Drainage Systems
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight">
              Pots & Planters Collection
            </h2>
            <p className="text-xs sm:text-sm text-[#d3e5dc] leading-relaxed max-w-xl">
              Elevate your botanicals with handcrafted fluted stoneware, weatherproof lightweight concrete, glazed ceramic, and designer hanging planters crafted for healthy root aeration.
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <button
                onClick={() => openWhatsAppChat('Hi Divyanshi Nursery, I am looking for custom sizes in Ceramic and Concrete Planters. Can you share the latest catalog?')}
                className="px-5 py-2.5 bg-emerald-400 hover:bg-emerald-300 text-[#14261d] text-xs font-bold rounded-xl transition-colors inline-flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Request Custom Bulk Pot Catalog</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden border border-white/20 shadow-xl bg-black/20">
              <img
                src="/src/assets/images/pots_designer_planters_1793198790397.jpg"
                alt="Curated pots and planters showcase"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Material Filter Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-8">
        <div className="flex items-center gap-1.5 p-1 bg-[#ede8df] rounded-xl text-xs font-medium overflow-x-auto max-w-full">
          {materials.map((mat) => (
            <button
              key={mat}
              onClick={() => setSelectedMaterial(mat)}
              className={`px-4 py-2 rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                selectedMaterial === mat
                  ? 'bg-[#1b382b] text-white shadow-xs font-semibold'
                  : 'text-[#385142] hover:text-[#14261d]'
              }`}
            >
              {mat === 'All' ? 'All Materials' : `${mat} Pots`}
            </button>
          ))}
        </div>

        <span className="text-xs text-[#52705f] font-mono tabular-nums">
          Showing {potProducts.length} planter designs
        </span>
      </div>

      {/* Pots Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {potProducts.map((pot) => (
          <ProductCard key={pot.id} product={pot} />
        ))}
      </div>
    </section>
  );
};

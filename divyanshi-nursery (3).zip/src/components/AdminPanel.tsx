import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Product, ProductCategory, LandscapingProject, ServicePackage } from '../types';
import { ImageUploader } from './ImageUploader';
import {
  Shield,
  LogOut,
  Plus,
  Trash2,
  Edit2,
  Save,
  CheckCircle,
  Clock,
  Phone,
  MessageCircle,
  Eye,
  Settings,
  Package,
  Layers,
  Wrench,
  Inbox,
  ShoppingBag,
  TrendingUp,
  X,
  Camera,
  Upload,
  Image as ImageIcon,
  Check,
  Sparkles,
  ArrowRight,
  RefreshCw,
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const {
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    projects,
    addProject,
    updateProject,
    deleteProject,
    services,
    updateService,
    addService,
    enquiries,
    updateEnquiryStatus,
    orders,
    updateOrderStatus,
    settings,
    updateSettings,
    isAdminLoggedIn,
    setIsAdminLoggedIn,
    setCurrentView,
    openWhatsAppChat,
    uploadImage,
  } = useApp();

  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');
  const [activeTab, setActiveTab] = useState<
    'overview' | 'plant-photos' | 'logo' | 'products' | 'services' | 'projects' | 'enquiries' | 'orders' | 'branding'
  >('overview');

  // Modal states for Product Add/Edit
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);

  // Quick Photo Replacement Modal for a specific product
  const [quickPhotoProduct, setQuickPhotoProduct] = useState<Product | null>(null);

  // Modal states for Project Add/Edit
  const [editingProject, setEditingProject] = useState<LandscapingProject | null>(null);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);

  // Settings form state
  const [settingsForm, setSettingsForm] = useState(settings);
  const [settingsSavedToast, setSettingsSavedToast] = useState(false);

  // Direct Plant Pictures Upload state
  const [uploadedPhotos, setUploadedPhotos] = useState<Array<{ id: string; url: string; name: string; timestamp: number }>>([
    { id: 'ph-1', url: '/src/assets/images/plant_fiddle_leaf_fig_1793198788666.jpg', name: 'Fiddle Leaf Fig', timestamp: Date.now() - 3600000 },
    { id: 'ph-2', url: '/src/assets/images/plant_monstera_deliciosa_1793198788974.jpg', name: 'Monstera Deliciosa', timestamp: Date.now() - 7200000 },
    { id: 'ph-3', url: '/src/assets/images/plant_snake_plant_1793198790249.jpg', name: 'Sansevieria Snake Plant', timestamp: Date.now() - 10800000 },
    { id: 'ph-4', url: '/src/assets/images/pots_designer_planters_1793198790397.jpg', name: 'Artisan Ceramic Pots', timestamp: Date.now() - 14400000 },
    { id: 'ph-5', url: '/src/assets/images/landscaping_terrace_garden_1793198790764.jpg', name: 'Terrace Garden Landscape', timestamp: Date.now() - 18000000 },
  ]);
  const [isBatchUploading, setIsBatchUploading] = useState(false);
  const batchFileInputRef = useRef<HTMLInputElement>(null);
  const [selectedPhotoForAssign, setSelectedPhotoForAssign] = useState<string | null>(null);
  const [assignTargetProductId, setAssignTargetProductId] = useState<string>(products[0]?.id || '');
  const [assignSuccessToast, setAssignSuccessToast] = useState<string | null>(null);

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === 'admin123' || passwordInput.trim() === 'admin' || passwordInput.trim() === 'nursery') {
      setIsAdminLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Incorrect password. Default access is: admin123');
    }
  };

  const handleLogout = () => {
    setIsAdminLoggedIn(false);
  };

  // Product Form Submissions
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct?.name || !editingProduct?.price) {
      alert('Please fill in product name and price.');
      return;
    }

    if (editingProduct.id) {
      await updateProduct(editingProduct.id, editingProduct);
    } else {
      await addProduct(editingProduct);
    }
    setIsProductModalOpen(false);
    setEditingProduct(null);
  };

  // Quick Direct Photo update for a product
  const handleDirectProductPhotoUpdate = async (product: Product, newPhotoUrl: string) => {
    await updateProduct(product.id, { image: newPhotoUrl });
    setQuickPhotoProduct(null);
    setAssignSuccessToast(`Photo updated for "${product.name}"!`);
    setTimeout(() => setAssignSuccessToast(null), 3500);
  };

  // Project Form Submissions
  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject?.title || !editingProject?.location) {
      alert('Please fill in project title and location.');
      return;
    }

    if (editingProject.id) {
      await updateProject(editingProject.id, editingProject);
    } else {
      await addProject(editingProject);
    }
    setIsProjectModalOpen(false);
    setEditingProject(null);
  };

  // Settings / Logo Save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateSettings(settingsForm);
    setSettingsSavedToast(true);
    setTimeout(() => setSettingsSavedToast(false), 3000);
  };

  // Direct Multiple Plant Photos Upload
  const handleBatchPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;

    setIsBatchUploading(true);
    const files = Array.from(e.target.files);
    const newItems: Array<{ id: string; url: string; name: string; timestamp: number }> = [];

    for (const file of files) {
      try {
        const url = await uploadImage(file);
        newItems.unshift({
          id: `photo-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          url,
          name: file.name.replace(/\.[^/.]+$/, ''),
          timestamp: Date.now(),
        });
      } catch (err) {
        console.error('Error uploading photo:', err);
      }
    }

    setUploadedPhotos((prev) => [...newItems, ...prev]);
    setIsBatchUploading(false);
    if (batchFileInputRef.current) batchFileInputRef.current.value = '';
    setAssignSuccessToast(`Successfully uploaded ${newItems.length} plant photos!`);
    setTimeout(() => setAssignSuccessToast(null), 3500);
  };

  // Assign uploaded photo to an existing plant
  const handleAssignPhotoToPlant = async () => {
    if (!selectedPhotoForAssign || !assignTargetProductId) return;

    const targetProduct = products.find((p) => p.id === assignTargetProductId);
    if (!targetProduct) return;

    await updateProduct(assignTargetProductId, { image: selectedPhotoForAssign });
    setSelectedPhotoForAssign(null);
    setAssignSuccessToast(`Photo assigned directly to "${targetProduct.name}"!`);
    setTimeout(() => setAssignSuccessToast(null), 3500);
  };

  // Create new plant directly from uploaded photo
  const handleCreatePlantFromPhoto = (photoUrl: string, photoName: string) => {
    setEditingProduct({
      id: '',
      name: photoName || 'New Exotic Plant',
      botanicalName: '',
      category: 'Indoor Plants',
      price: 999,
      discountPrice: 1299,
      image: photoUrl,
      description: 'Healthy acclimatized nursery specimen potted in nutrient-rich organic soil.',
      careInstructions: {
        sunlight: 'Bright indirect daylight',
        watering: 'Water when topsoil feels dry',
        maintenance: 'Low',
        placement: 'Living room, veranda, executive desk',
      },
      inStock: true,
      stockCount: 15,
      featured: true,
      tags: ['New Arrival'],
    });
    setIsProductModalOpen(true);
  };

  // If not logged in, show Login Screen
  if (!isAdminLoggedIn) {
    return (
      <section className="min-h-[75vh] flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-md w-full p-8 border border-[#ded8cb] shadow-xl text-center space-y-6">
          <div className="w-14 h-14 rounded-2xl bg-[#1b382b] text-emerald-300 flex items-center justify-center mx-auto shadow-md">
            <Shield className="w-7 h-7" />
          </div>

          <div>
            <h2 className="font-serif text-2xl font-bold text-[#14261d]">
              Divyanshi Admin Portal
            </h2>
            <p className="text-xs text-[#52705f] mt-1">
              Directly upload plant pictures, change the nursery logo, manage prices, and reply to customer inquiries.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 text-left">
            <div>
              <label className="block text-xs font-semibold text-[#14261d] mb-1">
                Admin Security Password
              </label>
              <input
                type="password"
                placeholder="Enter password (default: admin123)"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
              />
              {loginError && (
                <p className="text-[11px] text-red-600 font-medium mt-1">{loginError}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer shadow-sm"
            >
              Authenticate & Open Dashboard
            </button>
          </form>

          <div className="pt-2 border-t border-[#f0ebe0] text-center">
            <span className="text-[11px] text-[#789182]">
              Hint for Testing: <strong>admin123</strong>
            </span>
          </div>
        </div>
      </section>
    );
  }

  // Analytics Metrics
  const totalInStock = products.filter((p) => p.inStock).length;
  const newEnquiriesCount = enquiries.filter((e) => e.status === 'New').length;
  const pendingOrdersCount = orders.filter((o) => o.status === 'Pending').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
      {/* Toast Notification */}
      {assignSuccessToast && (
        <div className="fixed top-24 right-6 z-50 bg-[#1b382b] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-semibold animate-in slide-in-from-top duration-300">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{assignSuccessToast}</span>
        </div>
      )}

      {/* Admin Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-[#ded8cb]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 bg-[#1b382b] text-emerald-200 text-[10px] font-bold rounded uppercase tracking-wider">
              Verified Administrator
            </span>
            <span className="text-xs text-[#5a7667]">DIVYANSHI NURSERY CMS</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#14261d] mt-1">
            Master Control Center
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('home')}
            className="px-3.5 py-2 bg-[#ede8df] hover:bg-[#ded7c7] text-[#1b382b] text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>View Live Site</span>
          </button>

          <button
            onClick={handleLogout}
            className="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="overflow-x-auto pb-2 scrollbar-none my-6">
        <div className="flex items-center gap-1.5 min-w-max p-1 bg-[#ede8df] rounded-xl text-xs font-medium">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'overview' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Overview & KPIs</span>
          </button>

          <button
            onClick={() => setActiveTab('plant-photos')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'plant-photos' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <Camera className="w-3.5 h-3.5 text-emerald-300" />
            <span className="font-semibold">Direct Plant Picture Upload ({uploadedPhotos.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('logo')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'logo' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5 text-emerald-300" />
            <span className="font-semibold">Change Logo</span>
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'products' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Plant & Pot Catalog ({products.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('enquiries')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'enquiries' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <Inbox className="w-3.5 h-3.5" />
            <span>Enquiries ({enquiries.length})</span>
            {newEnquiriesCount > 0 && (
              <span className="w-4 h-4 bg-emerald-400 text-[#14261d] text-[10px] font-bold rounded-full flex items-center justify-center">
                {newEnquiriesCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'orders' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Orders ({orders.length})</span>
            {pendingOrdersCount > 0 && (
              <span className="w-4 h-4 bg-amber-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {pendingOrdersCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('projects')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'projects' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Landscaping Portfolio</span>
          </button>

          <button
            onClick={() => setActiveTab('services')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'services' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <Wrench className="w-3.5 h-3.5" />
            <span>Maintenance & AMC</span>
          </button>

          <button
            onClick={() => setActiveTab('branding')}
            className={`px-3.5 py-2 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'branding' ? 'bg-[#1b382b] text-white shadow-xs font-semibold' : 'text-[#385142] hover:text-[#14261d]'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Website Branding & Banners</span>
          </button>
        </div>
      </div>

      {/* TAB 1: OVERVIEW & KPIS */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Quick Highlight Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Direct Plant Picture Upload Quick Box */}
            <div className="p-6 bg-gradient-to-br from-[#1b382b] to-[#264b3a] text-white rounded-2xl shadow-md flex items-center justify-between">
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-300">
                  New Fast Tool
                </span>
                <h3 className="font-serif text-xl font-bold">Direct Plant Picture Upload</h3>
                <p className="text-xs text-[#c5dbce] max-w-sm">
                  Upload high-resolution plant photos from your device, attach them to existing plants, or launch new products instantly.
                </p>
                <button
                  onClick={() => setActiveTab('plant-photos')}
                  className="mt-3 px-4 py-2 bg-emerald-400 hover:bg-emerald-300 text-[#14261d] font-bold text-xs rounded-xl inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>Open Plant Picture Uploader</span>
                </button>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-white/10 flex items-center justify-center text-emerald-200 shrink-0">
                <Camera className="w-8 h-8" />
              </div>
            </div>

            {/* Change Nursery Logo Quick Box */}
            <div className="p-6 bg-white border border-[#ded8cb] text-[#14261d] rounded-2xl shadow-xs flex items-center justify-between">
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-bold tracking-wider text-[#3d654d]">
                  Branding Control
                </span>
                <h3 className="font-serif text-xl font-bold">Change Website Logo</h3>
                <p className="text-xs text-[#52705f] max-w-sm">
                  Upload your custom nursery emblem or logo image with live preview on the navigation bar.
                </p>
                <button
                  onClick={() => setActiveTab('logo')}
                  className="mt-3 px-4 py-2 bg-[#1b382b] hover:bg-[#254d3b] text-white font-bold text-xs rounded-xl inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ImageIcon className="w-4 h-4" />
                  <span>Change Nursery Logo</span>
                </button>
              </div>
              <div className="w-16 h-16 rounded-full bg-[#1b382b] flex items-center justify-center text-emerald-300 shrink-0 overflow-hidden border border-stone-200">
                {settings.logoImage ? (
                  <img src={settings.logoImage} alt="Logo" className="w-full h-full object-cover" />
                ) : (
                  <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
                  </svg>
                )}
              </div>
            </div>
          </div>

          {/* Metric KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
              <span className="text-xs text-[#5e7d6b] font-medium block">Total Plant Products</span>
              <span className="font-mono text-3xl font-bold text-[#14261d] tabular-nums mt-1 block">
                {products.length}
              </span>
              <span className="text-[11px] text-emerald-700 mt-1 block">
                ✓ {totalInStock} currently in stock
              </span>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
              <span className="text-xs text-[#5e7d6b] font-medium block">Active Enquiries</span>
              <span className="font-mono text-3xl font-bold text-[#14261d] tabular-nums mt-1 block">
                {enquiries.length}
              </span>
              <span className="text-[11px] text-amber-700 mt-1 block">
                ⚡ {newEnquiriesCount} need customer reply
              </span>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
              <span className="text-xs text-[#5e7d6b] font-medium block">Customer Orders</span>
              <span className="font-mono text-3xl font-bold text-[#14261d] tabular-nums mt-1 block">
                {orders.length}
              </span>
              <span className="text-[11px] text-[#5e7d6b] mt-1 block">
                📦 {pendingOrdersCount} pending dispatch
              </span>
            </div>

            <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
              <span className="text-xs text-[#5e7d6b] font-medium block">Turnkey Projects</span>
              <span className="font-mono text-3xl font-bold text-[#14261d] tabular-nums mt-1 block">
                {projects.length}
              </span>
              <span className="text-[11px] text-[#5e7d6b] mt-1 block">
                🌿 Before & after case studies
              </span>
            </div>
          </div>

          {/* Quick Actions Panel */}
          <div className="p-6 bg-[#ede8df] rounded-2xl border border-[#ded8cb]">
            <h3 className="font-serif text-lg font-bold text-[#14261d] mb-3">
              Fast Management Shortcuts
            </h3>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => {
                  setEditingProduct({
                    id: '',
                    name: '',
                    botanicalName: '',
                    category: 'Indoor Plants',
                    price: 999,
                    discountPrice: 1299,
                    image: '/src/assets/images/plant_fiddle_leaf_fig_1793198788666.jpg',
                    description: '',
                    careInstructions: {
                      sunlight: 'Bright indirect daylight',
                      watering: 'Water when top 2 inches feel dry',
                      maintenance: 'Low',
                      placement: 'Living room, desk, balcony',
                    },
                    inStock: true,
                    stockCount: 15,
                    featured: false,
                    tags: ['New Arrival'],
                  });
                  setIsProductModalOpen(true);
                }}
                className="px-4 py-2.5 bg-[#1b382b] text-white text-xs font-semibold rounded-xl hover:bg-[#254d3b] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Plant Product</span>
              </button>

              <button
                onClick={() => setActiveTab('plant-photos')}
                className="px-4 py-2.5 bg-white border border-[#ded8cb] text-[#1b382b] text-xs font-semibold rounded-xl hover:bg-[#faf9f6] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Batch Upload Plant Photos</span>
              </button>

              <button
                onClick={() => setActiveTab('logo')}
                className="px-4 py-2.5 bg-white border border-[#ded8cb] text-[#1b382b] text-xs font-semibold rounded-xl hover:bg-[#faf9f6] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <ImageIcon className="w-4 h-4" />
                <span>Change Nursery Logo</span>
              </button>

              <button
                onClick={() => setActiveTab('branding')}
                className="px-4 py-2.5 bg-white border border-[#ded8cb] text-[#1b382b] text-xs font-semibold rounded-xl hover:bg-[#faf9f6] transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Settings className="w-4 h-4" />
                <span>Edit Phone (9265706952) & Instagram</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DIRECT PLANT PICTURE UPLOAD & MEDIA MANAGER */}
      {activeTab === 'plant-photos' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#14261d]">
                Direct Plant Picture Upload System
              </h2>
              <p className="text-xs text-[#5e7d6b]">
                Drag and drop Full HD plant photos directly from your phone or computer. Use them to replace photos on existing plants or list new nursery arrivals in seconds.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => batchFileInputRef.current?.click()}
                disabled={isBatchUploading}
                className="px-4 py-2.5 bg-[#1b382b] hover:bg-[#254d3b] text-white text-xs font-bold rounded-xl transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
              >
                {isBatchUploading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Uploading Photos...</span>
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4" />
                    <span>Upload New Plant Pictures</span>
                  </>
                )}
              </button>
              <input
                ref={batchFileInputRef}
                type="file"
                multiple
                accept="image/*"
                onChange={handleBatchPhotoUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Drag & Drop Large Zone */}
          <div
            onClick={() => batchFileInputRef.current?.click()}
            className="border-2 border-dashed border-[#1b382b]/40 hover:border-[#1b382b] bg-[#f8f6f0] hover:bg-[#f1ede3] rounded-3xl p-8 sm:p-12 text-center cursor-pointer transition-all duration-200"
          >
            <div className="w-14 h-14 rounded-2xl bg-[#1b382b] text-emerald-300 flex items-center justify-center mx-auto mb-3 shadow-sm">
              <Camera className="w-7 h-7" />
            </div>
            <h3 className="font-serif text-lg font-bold text-[#14261d]">
              Click to Select or Drop Plant Photos Here
            </h3>
            <p className="text-xs text-[#52705f] mt-1 max-w-md mx-auto">
              Select one or multiple images at once. Supports JPG, PNG, WebP up to 15MB each with automatic compression and crisp HD rendering.
            </p>
            <div className="mt-4 flex items-center justify-center gap-3 text-[11px] text-[#3d654d] font-semibold">
              <span>✓ Instant High-Res Preview</span>
              <span aria-hidden="true">·</span>
              <span>✓ 1-Click Plant Assignment</span>
              <span aria-hidden="true">·</span>
              <span>✓ Direct Mobile Photo Support</span>
            </div>
          </div>

          {/* Uploaded Photos Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-serif text-base font-bold text-[#14261d]">
                Plant Photos Library ({uploadedPhotos.length} images available)
              </h3>
              <span className="text-[11px] text-[#6b8577]">
                Click any photo to attach it to a plant or create a new product
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {uploadedPhotos.map((photo) => (
                <div
                  key={photo.id}
                  className="bg-white rounded-2xl border border-[#ded8cb] overflow-hidden shadow-xs hover:shadow-md transition-all group flex flex-col justify-between"
                >
                  <div className="relative aspect-[4/3] bg-stone-100 overflow-hidden">
                    <img
                      src={photo.url}
                      alt={photo.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform group-hover:scale-105"
                    />

                    {/* Overlay Action Buttons */}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-3 gap-2">
                      <button
                        onClick={() => setSelectedPhotoForAssign(photo.url)}
                        className="w-full py-1.5 px-3 bg-white text-[#1b382b] rounded-lg text-xs font-bold hover:bg-[#ede8df] transition-colors shadow-sm"
                      >
                        Assign to Plant
                      </button>

                      <button
                        onClick={() => handleCreatePlantFromPhoto(photo.url, photo.name)}
                        className="w-full py-1.5 px-3 bg-emerald-700 text-white rounded-lg text-xs font-bold hover:bg-emerald-800 transition-colors shadow-sm"
                      >
                        Create New Plant
                      </button>

                      <button
                        onClick={async () => {
                          await updateSettings({ heroImage: photo.url });
                          setAssignSuccessToast('Set as Homepage Hero Banner!');
                          setTimeout(() => setAssignSuccessToast(null), 3000);
                        }}
                        className="w-full py-1.5 px-3 bg-stone-900/90 text-white rounded-lg text-[11px] font-medium hover:bg-black transition-colors"
                      >
                        Set as Hero Banner
                      </button>
                    </div>
                  </div>

                  <div className="p-3">
                    <p className="text-xs font-bold text-[#14261d] truncate">{photo.name}</p>
                    <div className="mt-2 pt-2 border-t border-[#f0ebe0] flex items-center justify-between text-[11px]">
                      <button
                        onClick={() => setSelectedPhotoForAssign(photo.url)}
                        className="text-[#2d5a3f] font-semibold hover:underline"
                      >
                        Attach to Plant →
                      </button>
                      <button
                        onClick={() => {
                          setUploadedPhotos((prev) => prev.filter((p) => p.id !== photo.id));
                        }}
                        className="text-stone-400 hover:text-red-600"
                        title="Remove from photo list"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: DEDICATED LOGO CHANGE PANEL */}
      {activeTab === 'logo' && (
        <div className="space-y-8 max-w-4xl">
          <div>
            <h2 className="font-serif text-2xl font-bold text-[#14261d]">
              Change Website Logo & Brand Identity
            </h2>
            <p className="text-xs text-[#5e7d6b]">
              Upload your nursery logo image directly or choose an elegant botanical emblem. Your logo updates automatically across the top navigation bar, footer, and mobile menus.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-6 sm:p-10 border border-[#ded8cb] shadow-sm space-y-8">
            
            {/* Live Interactive Navigation Bar Simulation Preview */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-[#14261d] block">
                Live Navbar Simulation (How your logo looks to customers right now):
              </span>

              <div className="p-4 bg-[#faf9f6] rounded-2xl border border-[#ded8cb] shadow-inner">
                <div className="flex items-center justify-between max-w-2xl mx-auto py-2 px-4 bg-white/90 rounded-xl border border-stone-200">
                  <div className="flex items-center gap-2.5">
                    {settingsForm.logoImage ? (
                      <img
                        src={settingsForm.logoImage}
                        alt="Logo Preview"
                        className="w-10 h-10 rounded-full object-cover border border-[#1b382b]/30 shadow-sm"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-[#1b382b] flex items-center justify-center text-[#d2e5d8] shadow-sm">
                        <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
                        </svg>
                      </div>
                    )}
                    <div>
                      <span className="font-serif text-lg font-bold text-[#1b382b] block leading-none">
                        {settingsForm.businessName}
                      </span>
                      <span className="text-[10px] uppercase tracking-wider text-[#52705f] font-medium block mt-0.5">
                        {settingsForm.tagline}
                      </span>
                    </div>
                  </div>

                  <div className="hidden sm:flex items-center gap-4 text-xs text-[#52705f]">
                    <span>All Plants</span>
                    <span>Maintenance</span>
                    <span>Landscaping</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Direct Logo Upload Component */}
            <div className="space-y-3 pt-4 border-t border-[#f0ebe0]">
              <ImageUploader
                label="Upload Logo Image (PNG, JPG, SVG, WebP with transparent or white background)"
                currentImage={settingsForm.logoImage}
                onImageSelected={(url) => setSettingsForm({ ...settingsForm, logoImage: url })}
                aspectRatioLabel="Square (1:1) / Circle"
                isLogo={true}
              />
            </div>

            {/* Revert or Clear Logo Option */}
            {settingsForm.logoImage && (
              <div className="flex items-center justify-between p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs">
                <span className="text-[#5e7d6b]">Using custom uploaded logo image</span>
                <button
                  type="button"
                  onClick={() => setSettingsForm({ ...settingsForm, logoImage: '' })}
                  className="text-red-700 font-semibold hover:underline"
                >
                  Reset to Default Botanical Leaf Icon
                </button>
              </div>
            )}

            {/* Logo Text & Brand Name Customization */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-[#f0ebe0] text-xs">
              <div>
                <label className="block font-semibold text-[#14261d] mb-1">
                  Nursery Brand Title in Header
                </label>
                <input
                  type="text"
                  value={settingsForm.businessName}
                  onChange={(e) => setSettingsForm({ ...settingsForm, businessName: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">
                  Nursery Tagline
                </label>
                <input
                  type="text"
                  value={settingsForm.tagline}
                  onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-6 border-t border-[#f0ebe0] flex items-center justify-between">
              <button
                type="button"
                onClick={handleSaveSettings}
                className="px-6 py-3 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-xs transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>Save Logo & Brand Updates</span>
              </button>

              {settingsSavedToast && (
                <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" />
                  Logo successfully updated across the website!
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: PRODUCTS CATALOG MANAGER */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#14261d]">
                Manage Plant & Pot Products
              </h2>
              <p className="text-xs text-[#5e7d6b]">
                Add new plants, update pricing, stock status, and replace photos directly with 1 click.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('plant-photos')}
                className="px-3.5 py-2 bg-[#ede8df] hover:bg-[#ded7c7] text-[#1b382b] text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Direct Picture Uploader</span>
              </button>

              <button
                onClick={() => {
                  setEditingProduct({
                    id: '',
                    name: '',
                    botanicalName: '',
                    category: 'Indoor Plants',
                    price: 899,
                    discountPrice: 1199,
                    image: '/src/assets/images/plant_monstera_deliciosa_1793198788974.jpg',
                    description: '',
                    careInstructions: {
                      sunlight: 'Bright filtered sunlight',
                      watering: 'Water twice weekly in summers',
                      maintenance: 'Low',
                      placement: 'Indoor or sheltered terrace',
                    },
                    inStock: true,
                    stockCount: 20,
                    featured: false,
                    tags: ['Fresh Arrival'],
                  });
                  setIsProductModalOpen(true);
                }}
                className="px-4 py-2 bg-[#1b382b] text-white text-xs font-semibold rounded-xl hover:bg-[#254d3b] transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Product</span>
              </button>
            </div>
          </div>

          {/* Products Table with Direct Quick Photo Action */}
          <div className="bg-white rounded-2xl border border-[#ded8cb] overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#f7f5f0] border-b border-[#ded8cb] text-[#52705f] font-semibold">
                  <tr>
                    <th className="py-3 px-4">Plant & Direct Photo</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Price</th>
                    <th className="py-3 px-4">Stock Status</th>
                    <th className="py-3 px-4">Featured</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0ebe0]">
                  {products.map((p) => (
                    <tr key={p.id} className="hover:bg-[#faf9f6] transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          {/* Product Thumbnail with 1-click Quick Photo Replace */}
                          <div className="relative group/pic w-12 h-12 rounded-lg overflow-hidden bg-stone-100 shrink-0 border border-stone-200">
                            <img
                              src={p.image}
                              alt={p.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover"
                            />
                            <button
                              onClick={() => setQuickPhotoProduct(p)}
                              title="Directly upload new picture for this plant"
                              className="absolute inset-0 bg-black/60 opacity-0 group-hover/pic:opacity-100 transition-opacity flex items-center justify-center text-white"
                            >
                              <Camera className="w-4 h-4" />
                            </button>
                          </div>

                          <div>
                            <p className="font-semibold text-[#14261d]">{p.name}</p>
                            {p.botanicalName && (
                              <p className="text-[11px] text-[#6b8577] italic">{p.botanicalName}</p>
                            )}
                            <button
                              onClick={() => setQuickPhotoProduct(p)}
                              className="text-[10px] text-[#2d5a3f] font-semibold hover:underline mt-0.5 block"
                            >
                              Change Picture 📷
                            </button>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 text-[#3c5547]">{p.category}</td>

                      <td className="py-3 px-4 font-mono tabular-nums font-semibold text-[#14261d]">
                        ₹{p.price.toLocaleString('en-IN')}
                      </td>

                      <td className="py-3 px-4">
                        <button
                          onClick={() => updateProduct(p.id, { inStock: !p.inStock })}
                          className={`px-2 py-0.5 rounded text-[11px] font-semibold cursor-pointer ${
                            p.inStock ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'
                          }`}
                        >
                          {p.inStock ? `In Stock (${p.stockCount})` : 'Out of Stock'}
                        </button>
                      </td>

                      <td className="py-3 px-4">
                        <button
                          onClick={() => updateProduct(p.id, { featured: !p.featured })}
                          className="text-xs text-[#2d5a3f] font-semibold cursor-pointer"
                        >
                          {p.featured ? '★ Featured' : '☆ Normal'}
                        </button>
                      </td>

                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          onClick={() => {
                            setEditingProduct({ ...p });
                            setIsProductModalOpen(true);
                          }}
                          className="p-1.5 text-[#5e7d6b] hover:text-[#1b382b] hover:bg-[#ede8df] rounded-lg transition-colors cursor-pointer"
                          title="Edit Product"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete ${p.name}?`)) {
                              deleteProduct(p.id);
                            }
                          }}
                          className="p-1.5 text-[#8f9b93] hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                          title="Delete Product"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: CUSTOMER ENQUIRIES */}
      {activeTab === 'enquiries' && (
        <div className="space-y-6">
          <div>
            <h2 className="font-serif text-xl font-bold text-[#14261d]">
              Customer Enquiries & Service Leads
            </h2>
            <p className="text-xs text-[#5e7d6b]">
              Direct contact requests from website visitors. Click "WhatsApp Customer" to message them immediately.
            </p>
          </div>

          <div className="space-y-3">
            {enquiries.length === 0 ? (
              <div className="p-8 bg-white rounded-2xl border border-[#ded8cb] text-center text-xs text-[#5e7d6b]">
                No customer enquiries recorded yet.
              </div>
            ) : (
              enquiries.map((enq) => (
                <div
                  key={enq.id}
                  className="p-5 bg-white rounded-2xl border border-[#ded8cb] shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 max-w-xl">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-[#14261d]">{enq.customerName}</span>
                      <span className="text-xs font-mono tabular-nums text-[#4b6656]">{enq.phone}</span>
                      <span className="text-[11px] text-[#718c7e]">
                        {new Date(enq.createdAt).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>

                    <div className="text-xs text-[#2b4737] font-medium">
                      <span>Service: <strong>{enq.serviceType}</strong></span>
                      {enq.location && <span> · Location: <strong>{enq.location}</strong></span>}
                    </div>

                    <p className="text-xs text-[#526d5e] bg-[#faf9f6] p-2.5 rounded-lg border border-[#f0ebe0]">
                      "{enq.message}"
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <select
                      value={enq.status}
                      onChange={(e) => updateEnquiryStatus(enq.id, e.target.value as any)}
                      className="px-2.5 py-1.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#14261d] font-medium"
                    >
                      <option value="New">Status: New</option>
                      <option value="Contacted">Status: Contacted</option>
                      <option value="In Progress">Status: In Progress</option>
                      <option value="Completed">Status: Completed</option>
                    </select>

                    <button
                      onClick={() => {
                        const cleanPhone = enq.phone.replace(/[^0-9]/g, '');
                        const target = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
                        const msg = encodeURIComponent(
                          `Hello ${enq.customerName}! Thank you for contacting Divyanshi Nursery regarding "${enq.serviceType}". We are pleased to help. When would you like to schedule?`
                        );
                        window.open(`https://wa.me/${target}?text=${msg}`, '_blank');
                      }}
                      className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>WhatsApp Customer</span>
                    </button>

                    <a
                      href={`tel:${enq.phone}`}
                      className="px-3 py-1.5 bg-[#ede8df] hover:bg-[#ded7c7] text-[#1b382b] rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call</span>
                    </a>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 6: ORDERS */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div>
            <h2 className="font-serif text-xl font-bold text-[#14261d]">
              Customer Plant Orders
            </h2>
            <p className="text-xs text-[#5e7d6b]">
              Online bag checkout orders with customer delivery address and payment status.
            </p>
          </div>

          <div className="space-y-4">
            {orders.length === 0 ? (
              <div className="p-8 bg-white rounded-2xl border border-[#ded8cb] text-center text-xs text-[#5e7d6b]">
                No customer orders placed yet. They will appear here immediately after checkout.
              </div>
            ) : (
              orders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-5 bg-white rounded-2xl border border-[#ded8cb] shadow-xs space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#f0ebe0]">
                    <div>
                      <span className="font-mono text-xs font-bold text-[#1b382b]">#{ord.id}</span>
                      <span className="text-xs text-[#5e7d6b] ml-2">
                        {new Date(ord.createdAt).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </span>
                      <h4 className="font-bold text-sm text-[#14261d] mt-0.5">
                        {ord.customerName} · <span className="font-mono">{ord.phone}</span>
                      </h4>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="font-mono text-lg font-bold text-[#14261d] tabular-nums">
                        ₹{ord.totalAmount.toLocaleString('en-IN')}
                      </span>
                      <select
                        value={ord.status}
                        onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                        className="px-2.5 py-1 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs font-semibold text-[#14261d]"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Dispatched">Dispatched</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>

                  <div className="text-xs text-[#395344] space-y-1">
                    <p>
                      <strong>Delivery Address:</strong> {ord.address}, {ord.city} - {ord.pincode}
                    </p>
                    <p>
                      <strong>Payment Mode:</strong> {ord.paymentMethod}
                    </p>
                  </div>

                  <div className="pt-2 flex flex-wrap gap-2">
                    {ord.items.map((item: any, i: number) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 p-1.5 bg-[#faf9f6] rounded-lg border border-[#ece6d9] text-xs"
                      >
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-7 h-7 rounded object-cover"
                        />
                        <span className="font-medium text-[#14261d]">{item.name}</span>
                        <span className="text-[#688273] font-mono tabular-nums">x{item.quantity}</span>
                        <span className="font-mono font-bold text-[#1b382b]">
                          ₹{item.price * item.quantity}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 7: LANDSCAPING PROJECTS MANAGER */}
      {activeTab === 'projects' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-serif text-xl font-bold text-[#14261d]">
                Landscaping Portfolio Projects
              </h2>
              <p className="text-xs text-[#5e7d6b]">
                Add terrace gardens, villa transformations, before/after photographs, and case studies.
              </p>
            </div>

            <button
              onClick={() => {
                setEditingProject({
                  id: '',
                  title: '',
                  category: 'Terrace & Rooftop Gardens',
                  location: 'Ahmedabad, Gujarat',
                  clientType: 'Terrace',
                  areaSize: '1,500 sq. ft.',
                  description: '',
                  beforeImage: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
                  afterImage: '/src/assets/images/landscaping_terrace_garden_1793198790764.jpg',
                  completedYear: '2026',
                  keyHighlights: ['Complete drainage grid', 'Tropical planting'],
                });
                setIsProjectModalOpen(true);
              }}
              className="px-4 py-2 bg-[#1b382b] text-white text-xs font-semibold rounded-xl hover:bg-[#254d3b] transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Project</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((proj) => (
              <div
                key={proj.id}
                className="bg-white rounded-2xl border border-[#ded8cb] overflow-hidden flex flex-col justify-between"
              >
                <div>
                  <div className="relative aspect-[16/10] bg-stone-100">
                    <img
                      src={proj.afterImage}
                      alt={proj.title}
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute top-2 left-2 px-2 py-0.5 bg-black/60 text-white text-[10px] rounded">
                      {proj.category}
                    </span>
                  </div>

                  <div className="p-4">
                    <h4 className="font-serif text-base font-bold text-[#14261d]">{proj.title}</h4>
                    <p className="text-xs text-[#52705f] mt-1">{proj.location} · {proj.areaSize}</p>
                    <p className="text-xs text-[#425a4c] mt-2 line-clamp-2">{proj.description}</p>
                  </div>
                </div>

                <div className="p-4 pt-0 flex items-center justify-end gap-2 border-t border-[#f0ebe0]">
                  <button
                    onClick={() => {
                      setEditingProject({ ...proj });
                      setIsProjectModalOpen(true);
                    }}
                    className="p-1.5 text-[#5e7d6b] hover:text-[#1b382b] hover:bg-[#ede8df] rounded-lg cursor-pointer"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Delete project "${proj.title}"?`)) {
                        deleteProject(proj.id);
                      }
                    }}
                    className="p-1.5 text-stone-400 hover:text-red-600 rounded-lg cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 8: SERVICES & AMC */}
      {activeTab === 'services' && (
        <div className="space-y-6">
          <div>
            <h2 className="font-serif text-xl font-bold text-[#14261d]">
              Maintenance & Landscaping Services
            </h2>
            <p className="text-xs text-[#5e7d6b]">
              Edit service descriptions, pricing starting rates, and inclusions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((serv) => (
              <div
                key={serv.id}
                className="bg-white rounded-2xl p-6 border border-[#ded8cb] shadow-xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[#3d654d] tracking-wider">
                      {serv.category}
                    </span>
                    <h3 className="font-serif text-lg font-bold text-[#14261d]">{serv.title}</h3>
                    <p className="text-xs text-[#5e7d6b]">{serv.subtitle}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-mono text-base font-bold text-[#14261d]">
                      ₹{serv.priceStartingFrom.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[10px] text-[#718c7e] block">/{serv.pricingUnit}</span>
                  </div>
                </div>

                <p className="text-xs text-[#3d5648] leading-relaxed">{serv.description}</p>

                <div className="pt-2 border-t border-[#f0ebe0] space-y-1">
                  {serv.features.map((f, idx) => (
                    <div key={idx} className="text-xs text-[#3d5648] flex items-center gap-1.5">
                      <span className="text-emerald-700">✓</span>
                      <span>{f}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 9: BRANDING & SITE SETTINGS */}
      {activeTab === 'branding' && (
        <form onSubmit={handleSaveSettings} className="space-y-6 max-w-4xl">
          <div>
            <h2 className="font-serif text-xl font-bold text-[#14261d]">
              Website Branding, Hero & Contact Details
            </h2>
            <p className="text-xs text-[#5e7d6b]">
              Update the business name, tagline, direct phone, WhatsApp number, Instagram handle, and Hero Banner image.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#ded8cb] shadow-xs space-y-6">
            <h3 className="font-serif text-base font-bold text-[#14261d] pb-2 border-b border-[#f0ebe0]">
              Identity & Contact Coordinates
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Business Name</label>
                <input
                  type="text"
                  value={settingsForm.businessName}
                  onChange={(e) => setSettingsForm({ ...settingsForm, businessName: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Tagline</label>
                <input
                  type="text"
                  value={settingsForm.tagline}
                  onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Phone Number (Calling)</label>
                <input
                  type="text"
                  value={settingsForm.phone}
                  onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">WhatsApp Chat Number</label>
                <input
                  type="text"
                  value={settingsForm.whatsapp}
                  onChange={(e) => setSettingsForm({ ...settingsForm, whatsapp: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Instagram Handle</label>
                <input
                  type="text"
                  value={settingsForm.instagram}
                  onChange={(e) => setSettingsForm({ ...settingsForm, instagram: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Official Email</label>
                <input
                  type="email"
                  value={settingsForm.email}
                  onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#14261d] mb-1">Physical Nursery Address</label>
              <textarea
                rows={2}
                value={settingsForm.address}
                onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
              />
            </div>

            {/* Announcement Bar */}
            <div className="pt-4 border-t border-[#f0ebe0] space-y-3">
              <h3 className="font-serif text-base font-bold text-[#14261d]">Top Announcement Banner</h3>
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="annEnabled"
                  checked={settingsForm.announcementBar.enabled}
                  onChange={(e) =>
                    setSettingsForm({
                      ...settingsForm,
                      announcementBar: { ...settingsForm.announcementBar, enabled: e.target.checked },
                    })
                  }
                  className="accent-[#1b382b]"
                />
                <label htmlFor="annEnabled" className="text-xs font-medium text-[#14261d]">
                  Enable top notification ticker
                </label>
              </div>
              <input
                type="text"
                value={settingsForm.announcementBar.text}
                onChange={(e) =>
                  setSettingsForm({
                    ...settingsForm,
                    announcementBar: { ...settingsForm.announcementBar, text: e.target.value },
                  })
                }
                className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
              />
            </div>

            {/* Homepage Hero Texts & Direct Image Upload */}
            <div className="pt-4 border-t border-[#f0ebe0] space-y-4">
              <h3 className="font-serif text-base font-bold text-[#14261d]">Homepage Hero Section</h3>

              <div>
                <label className="block text-xs font-semibold text-[#14261d] mb-1">Hero Main Headline</label>
                <input
                  type="text"
                  value={settingsForm.heroHeadline}
                  onChange={(e) => setSettingsForm({ ...settingsForm, heroHeadline: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#14261d] mb-1">Hero Supporting Subtitle</label>
                <textarea
                  rows={2}
                  value={settingsForm.heroSubtitle}
                  onChange={(e) => setSettingsForm({ ...settingsForm, heroSubtitle: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              {/* Hero Banner Direct Image Upload */}
              <ImageUploader
                label="Hero Photography Banner (Full HD)"
                currentImage={settingsForm.heroImage}
                onImageSelected={(url) => setSettingsForm({ ...settingsForm, heroImage: url })}
                aspectRatioLabel="16:9 or 4:3"
              />
            </div>

            {/* Google Pay & UPI Payment Settings */}
            <div className="pt-4 border-t border-[#f0ebe0] space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-base font-bold text-[#14261d]">Google Pay & UPI Payment QR Settings</h3>
                  <p className="text-xs text-[#5e7d6b]">Customers scan this QR code during checkout and on the contact page.</p>
                </div>
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">Active</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Payee Name (as displayed on QR)</label>
                  <input
                    type="text"
                    value={settingsForm.upiDetails?.payeeName || 'RAJKUMAR CHAUHAN (MR CHAUHAN)'}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        upiDetails: {
                          payeeName: e.target.value,
                          upiId: settingsForm.upiDetails?.upiId || 'rajkumarrc528389-1@okaxis',
                          qrCodeImage: settingsForm.upiDetails?.qrCodeImage || '/assets/aistudio/GooglePay_QR__2__08e43f63.png',
                        },
                      })
                    }
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">UPI ID (VPA)</label>
                  <input
                    type="text"
                    value={settingsForm.upiDetails?.upiId || 'rajkumarrc528389-1@okaxis'}
                    onChange={(e) =>
                      setSettingsForm({
                        ...settingsForm,
                        upiDetails: {
                          payeeName: settingsForm.upiDetails?.payeeName || 'RAJKUMAR CHAUHAN (MR CHAUHAN)',
                          upiId: e.target.value,
                          qrCodeImage: settingsForm.upiDetails?.qrCodeImage || '/assets/aistudio/GooglePay_QR__2__08e43f63.png',
                        },
                      })
                    }
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>
              </div>

              <ImageUploader
                label="Google Pay / UPI QR Code Image"
                currentImage={settingsForm.upiDetails?.qrCodeImage || '/assets/aistudio/GooglePay_QR__2__08e43f63.png'}
                onImageSelected={(url) =>
                  setSettingsForm({
                    ...settingsForm,
                    upiDetails: {
                      payeeName: settingsForm.upiDetails?.payeeName || 'RAJKUMAR CHAUHAN (MR CHAUHAN)',
                      upiId: settingsForm.upiDetails?.upiId || 'rajkumarrc528389-1@okaxis',
                      qrCodeImage: url,
                    },
                  })
                }
                aspectRatioLabel="QR Code Image"
                isLogo={true}
              />
            </div>

            {/* Save Button */}
            <div className="pt-4 border-t border-[#f0ebe0] flex items-center justify-between">
              <button
                type="submit"
                className="px-6 py-3 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-xs transition-colors flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>Save Website Changes</span>
              </button>

              {settingsSavedToast && (
                <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                  <CheckCircle className="w-4 h-4" />
                  All website changes applied live!
                </span>
              )}
            </div>
          </div>
        </form>
      )}

      {/* QUICK MODAL: DIRECT PLANT PICTURE REPLACEMENT */}
      {quickPhotoProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="relative bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-[#ded8cb] my-8 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#ded8cb]">
              <div>
                <span className="text-[10px] uppercase font-bold text-[#3d654d] tracking-wider">
                  Quick Photo Replacement
                </span>
                <h3 className="font-serif text-lg font-bold text-[#14261d]">
                  {quickPhotoProduct.name}
                </h3>
              </div>
              <button
                onClick={() => setQuickPhotoProduct(null)}
                className="p-1 text-[#6b8577] hover:text-[#14261d]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <ImageUploader
                label="Select or Drag New Picture for this Plant"
                currentImage={quickPhotoProduct.image}
                onImageSelected={(url) => {
                  handleDirectProductPhotoUpdate(quickPhotoProduct, url);
                }}
                aspectRatioLabel="4:3 aspect ratio"
              />
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ASSIGN PHOTO TO PLANT */}
      {selectedPhotoForAssign && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="relative bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-[#ded8cb] my-8 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#ded8cb]">
              <h3 className="font-serif text-lg font-bold text-[#14261d]">
                Assign Photo to Plant
              </h3>
              <button
                onClick={() => setSelectedPhotoForAssign(null)}
                className="p-1 text-[#6b8577] hover:text-[#14261d]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="aspect-[4/3] rounded-xl overflow-hidden bg-stone-100 border border-stone-200">
              <img
                src={selectedPhotoForAssign}
                alt="Selected"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-1.5 text-xs">
              <label className="font-semibold text-[#14261d]">Select Plant from Catalog:</label>
              <select
                value={assignTargetProductId}
                onChange={(e) => setAssignTargetProductId(e.target.value)}
                className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
              >
                {products.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} (₹{p.price}) - {p.category}
                  </option>
                ))}
              </select>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setSelectedPhotoForAssign(null)}
                className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleAssignPhotoToPlant}
                className="px-5 py-2 bg-[#1b382b] hover:bg-[#254d3b] text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Confirm Assignment</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRODUCT ADD/EDIT MODAL */}
      {isProductModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="relative bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-[#ded8cb] my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#ded8cb] mb-4">
              <h3 className="font-serif text-lg font-bold text-[#14261d]">
                {editingProduct.id ? 'Edit Plant or Product' : 'Add New Plant / Pot'}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="p-1 text-[#6b8577] hover:text-[#14261d]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Product Name *</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.name}
                    onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Botanical / Latin Name</label>
                  <input
                    type="text"
                    value={editingProduct.botanicalName || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, botanicalName: e.target.value })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Category</label>
                  <select
                    value={editingProduct.category}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, category: e.target.value as ProductCategory })
                    }
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  >
                    <option value="Indoor Plants">Indoor Plants</option>
                    <option value="Outdoor Plants">Outdoor Plants</option>
                    <option value="Flowering Plants">Flowering Plants</option>
                    <option value="Fruit Plants">Fruit Plants</option>
                    <option value="Air-Purifying Plants">Air-Purifying Plants</option>
                    <option value="Ornamental Plants">Ornamental Plants</option>
                    <option value="Succulents and Cacti">Succulents and Cacti</option>
                    <option value="Trees and Shrubs">Trees and Shrubs</option>
                    <option value="Medicinal Plants">Medicinal Plants</option>
                    <option value="Seeds and Gardening Supplies">Seeds and Gardening Supplies</option>
                    <option value="Pots and Planters">Pots and Planters</option>
                    <option value="Garden Accessories">Garden Accessories</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Selling Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Original / Strikethrough Price (₹)</label>
                  <input
                    type="number"
                    value={editingProduct.discountPrice || ''}
                    onChange={(e) =>
                      setEditingProduct({ ...editingProduct, discountPrice: Number(e.target.value) || undefined })
                    }
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>
              </div>

              {/* Direct Image Upload for Product */}
              <ImageUploader
                label="Product Photograph (Full HD)"
                currentImage={editingProduct.image}
                onImageSelected={(url) => setEditingProduct({ ...editingProduct, image: url })}
                aspectRatioLabel="4:3 aspect ratio"
              />

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editingProduct.description}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              {/* Care Instructions */}
              <div className="p-3 bg-[#faf9f6] rounded-xl border border-[#ece6d9] space-y-2">
                <span className="font-semibold text-[#14261d] block">Care Guide Settings:</span>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    placeholder="Sunlight requirement"
                    value={editingProduct.careInstructions?.sunlight || ''}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        careInstructions: { ...editingProduct.careInstructions, sunlight: e.target.value },
                      })
                    }
                    className="px-2.5 py-1.5 bg-white border border-[#d6cfc0] rounded-lg text-xs"
                  />
                  <input
                    type="text"
                    placeholder="Watering frequency"
                    value={editingProduct.careInstructions?.watering || ''}
                    onChange={(e) =>
                      setEditingProduct({
                        ...editingProduct,
                        careInstructions: { ...editingProduct.careInstructions, watering: e.target.value },
                      })
                    }
                    className="px-2.5 py-1.5 bg-white border border-[#d6cfc0] rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingProduct.inStock}
                    onChange={(e) => setEditingProduct({ ...editingProduct, inStock: e.target.checked })}
                    className="accent-[#1b382b]"
                  />
                  <span className="font-semibold text-[#14261d]">Available In Stock</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editingProduct.featured}
                    onChange={(e) => setEditingProduct({ ...editingProduct, featured: e.target.checked })}
                    className="accent-[#1b382b]"
                  />
                  <span className="font-semibold text-[#14261d]">Feature on Homepage</span>
                </label>
              </div>

              <div className="pt-4 border-t border-[#ded8cb] flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#1b382b] hover:bg-[#254d3b] text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Product</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PROJECT ADD/EDIT MODAL */}
      {isProjectModalOpen && editingProject && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="relative bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-[#ded8cb] my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#ded8cb] mb-4">
              <h3 className="font-serif text-lg font-bold text-[#14261d]">
                {editingProject.id ? 'Edit Landscape Project' : 'Add New Landscape Project'}
              </h3>
              <button
                onClick={() => setIsProjectModalOpen(false)}
                className="p-1 text-[#6b8577] hover:text-[#14261d]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProject} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Project Title *</label>
                  <input
                    type="text"
                    required
                    value={editingProject.title}
                    onChange={(e) => setEditingProject({ ...editingProject, title: e.target.value })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Category</label>
                  <input
                    type="text"
                    value={editingProject.category}
                    onChange={(e) => setEditingProject({ ...editingProject, category: e.target.value })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Location *</label>
                  <input
                    type="text"
                    required
                    value={editingProject.location}
                    onChange={(e) => setEditingProject({ ...editingProject, location: e.target.value })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Area Size</label>
                  <input
                    type="text"
                    value={editingProject.areaSize}
                    onChange={(e) => setEditingProject({ ...editingProject, areaSize: e.target.value })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Completed Year</label>
                  <input
                    type="text"
                    value={editingProject.completedYear}
                    onChange={(e) => setEditingProject({ ...editingProject, completedYear: e.target.value })}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                  />
                </div>
              </div>

              {/* Direct Image Upload for Completed Project */}
              <ImageUploader
                label="Completed Garden Photo (After)"
                currentImage={editingProject.afterImage}
                onImageSelected={(url) => setEditingProject({ ...editingProject, afterImage: url })}
                aspectRatioLabel="16:9 or 16:10"
              />

              {/* Before Photo */}
              <ImageUploader
                label="Original Site State Photo (Before)"
                currentImage={editingProject.beforeImage}
                onImageSelected={(url) => setEditingProject({ ...editingProject, beforeImage: url })}
                aspectRatioLabel="16:9 or 16:10"
              />

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Project Description & Scope</label>
                <textarea
                  rows={2}
                  value={editingProject.description}
                  onChange={(e) => setEditingProject({ ...editingProject, description: e.target.value })}
                  className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b]"
                />
              </div>

              <div className="pt-4 border-t border-[#ded8cb] flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsProjectModalOpen(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#1b382b] hover:bg-[#254d3b] text-white rounded-lg text-xs font-semibold flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Project</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, MapPin, CheckCircle, Send, MessageCircle, ArrowRight, Layers, Eye } from 'lucide-react';

export const LandscapingSection: React.FC = () => {
  const { projects, addEnquiry, openWhatsAppChat } = useApp();

  const [activeTab, setActiveTab] = useState<'All' | 'Terrace' | 'Residential' | 'Commercial'>('All');
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);

  // Form State
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [serviceType, setServiceType] = useState('Terrace and Rooftop Gardens');
  const [message, setMessage] = useState('');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const filteredProjects = projects.filter((p) => {
    if (activeTab === 'All') return true;
    if (activeTab === 'Terrace') return p.clientType === 'Terrace';
    if (activeTab === 'Residential') return p.clientType === 'Residential' || p.clientType === 'Villa';
    if (activeTab === 'Commercial') return p.clientType === 'Commercial';
    return true;
  });

  const handleEnquirySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone || !location) {
      alert('Please provide your name, phone number, and project location.');
      return;
    }

    setIsSubmitting(true);
    try {
      await addEnquiry({
        customerName,
        phone,
        serviceType: `Landscaping: ${serviceType}`,
        location,
        message: message || 'Customer requested a turnkey landscaping quote and site visit.',
      });
      setFormSubmitted(true);
    } catch (_err) {
      alert('Failed to submit enquiry. Please message us directly on WhatsApp.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleWhatsAppQuote = () => {
    const text = `Hi Divyanshi Nursery, I would like to get a quote for a Landscaping Project.\nName: ${customerName || 'Customer'}\nPhone: ${phone || 'Available'}\nLocation: ${location || 'Gujarat'}\nService: ${serviceType}\nDetails: ${message || 'Need complete garden master planning and cost estimate.'}`;
    openWhatsAppChat(text);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      {/* Header */}
      <div className="max-w-3xl mb-12">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#3d654d] mb-2">
          <span>Turnkey Landscape Architecture</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#14261d] tracking-tight">
          Landscaping & Garden Design Portfolio
        </h2>
        <p className="mt-3 text-base text-[#466152] leading-relaxed">
          From tranquil penthouse sky gardens to expansive residential farmhouses and corporate vertical biophilic facades — we conceptualize, engineer, and execute breathtaking green spaces.
        </p>
      </div>

      {/* Capabilities Overview Bento */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-16">
        <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
          <h4 className="font-serif text-base font-bold text-[#14261d] mb-1">Terrace & Rooftops</h4>
          <p className="text-xs text-[#526d5e]">Lightweight soil matrices, drip irrigation, teak decking, and wind buffering.</p>
        </div>
        <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
          <h4 className="font-serif text-base font-bold text-[#14261d] mb-1">Lawn Installation</h4>
          <p className="text-xs text-[#526d5e]">Premium Korean carpet turf, Mexican grass rolls, and sub-surface soil leveling.</p>
        </div>
        <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
          <h4 className="font-serif text-base font-bold text-[#14261d] mb-1">Vertical Green Walls</h4>
          <p className="text-xs text-[#526d5e]">Patented bio-wall felt pockets with automated fertigation and zero leakage.</p>
        </div>
        <div className="p-5 bg-white rounded-2xl border border-[#ded8cb]">
          <h4 className="font-serif text-base font-bold text-[#14261d] mb-1">Villa Courtyards</h4>
          <p className="text-xs text-[#526d5e]">Natural stone water fountains, exotic specimen palms, and zen rock paths.</p>
        </div>
      </div>

      {/* Portfolio Filter Tabs */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-8">
        <div className="flex items-center gap-1.5 p-1 bg-[#ede8df] rounded-xl text-xs font-medium">
          {(['All', 'Terrace', 'Residential', 'Commercial'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg transition-all cursor-pointer ${
                activeTab === tab
                  ? 'bg-[#1b382b] text-white shadow-xs font-semibold'
                  : 'text-[#385142] hover:text-[#14261d]'
              }`}
            >
              {tab === 'All' ? 'All Projects' : `${tab} Gardens`}
            </button>
          ))}
        </div>

        <span className="text-xs text-[#627d6e] tabular-nums font-mono">
          {filteredProjects.length} completed projects documented
        </span>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
        {filteredProjects.map((proj) => (
          <div
            key={proj.id}
            onClick={() => setSelectedProject(proj)}
            className="group bg-white rounded-2xl border border-[#ded8cb] overflow-hidden hover:border-[#1b382b]/50 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              {/* After Project Photo */}
              <div className="relative aspect-[16/10] bg-[#f5f2eb] overflow-hidden">
                <img
                  src={proj.afterImage}
                  alt={proj.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = '/src/assets/images/landscaping_terrace_garden_1793198790764.jpg';
                  }}
                />
                <span className="absolute top-3 left-3 px-2.5 py-1 bg-black/60 backdrop-blur-sm text-white text-[11px] font-medium rounded-md">
                  {proj.category}
                </span>

                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="px-3.5 py-1.5 bg-white/95 text-xs font-semibold text-[#1b382b] rounded-lg shadow-sm flex items-center gap-1.5">
                    <Eye className="w-3.5 h-3.5" />
                    Inspect Details & Before Photo
                  </span>
                </div>
              </div>

              {/* Card Meta & Title */}
              <div className="p-5">
                <div className="flex items-center gap-1.5 text-xs text-[#5a7667] mb-1.5">
                  <MapPin className="w-3.5 h-3.5 text-[#2d5a3f]" />
                  <span>{proj.location}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{proj.areaSize}</span>
                </div>

                <h3 className="font-serif text-lg font-bold text-[#14261d] group-hover:text-[#2d5a3f] transition-colors leading-snug">
                  {proj.title}
                </h3>

                <p className="text-xs text-[#526d5e] mt-2 line-clamp-2 leading-relaxed">
                  {proj.description}
                </p>

                {/* Highlights */}
                <div className="mt-4 pt-3 border-t border-[#f0ebe0] space-y-1.5">
                  {proj.keyHighlights.slice(0, 2).map((item, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-[11px] text-[#3c5647]">
                      <CheckCircle className="w-3 h-3 text-emerald-700 shrink-0" />
                      <span className="truncate">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-5 pt-0">
              <span className="text-xs font-semibold text-[#2d5a3f] group-hover:underline flex items-center gap-1">
                <span>View Full Project Case Study</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Selected Project Full Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="relative bg-white rounded-2xl max-w-4xl w-full overflow-hidden shadow-2xl border border-[#ded8cb] my-8 p-6 sm:p-8">
            <div className="flex items-center justify-between pb-4 border-b border-[#ded8cb] mb-6">
              <div>
                <span className="text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
                  {selectedProject.category} · {selectedProject.completedYear}
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#14261d] mt-1">
                  {selectedProject.title}
                </h3>
                <p className="text-xs text-[#52705f] flex items-center gap-1 mt-1">
                  <MapPin className="w-3.5 h-3.5" /> {selectedProject.location} ({selectedProject.areaSize})
                </p>
              </div>
              <button
                onClick={() => setSelectedProject(null)}
                className="px-3 py-1.5 bg-[#ede8df] hover:bg-[#ded7c7] text-[#1b382b] rounded-lg text-xs font-semibold"
              >
                Close
              </button>
            </div>

            {/* Before vs After Side-by-side */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <span className="text-xs font-semibold text-[#8b4f3b] block mb-1">Original Site Before:</span>
                <div className="aspect-[16/10] rounded-xl overflow-hidden bg-stone-100 border border-stone-300">
                  <img
                    src={selectedProject.beforeImage}
                    alt="Before site state"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div>
                <span className="text-xs font-semibold text-emerald-800 block mb-1">Divyanshi Executed Transformation:</span>
                <div className="aspect-[16/10] rounded-xl overflow-hidden bg-stone-100 border border-emerald-300">
                  <img
                    src={selectedProject.afterImage}
                    alt="Completed landscape"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-[#385142] leading-relaxed mb-4">
              {selectedProject.description}
            </p>

            <div className="pt-4 border-t border-[#f0ebe0] flex flex-wrap items-center justify-between gap-4">
              <div className="flex flex-wrap gap-2">
                {selectedProject.keyHighlights.map((hl, i) => (
                  <span key={i} className="text-xs text-[#204430] bg-[#e8f0ec] px-2.5 py-1 rounded-md font-medium">
                    ✓ {hl}
                  </span>
                ))}
              </div>
              <button
                onClick={() => {
                  setSelectedProject(null);
                  openWhatsAppChat(`Hi Divyanshi Nursery, I saw your project "${selectedProject.title}" and would love to get a similar design consultation.`);
                }}
                className="px-4 py-2 bg-[#1b382b] hover:bg-[#254d3b] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Discuss Similar Project on WhatsApp</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Project Enquiry Form Section */}
      <div className="bg-[#1b382b] text-white rounded-3xl p-6 sm:p-12 shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          <div className="lg:col-span-5 space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-300">
              Free Site Consultation
            </span>
            <h3 className="font-serif text-3xl sm:text-4xl font-bold leading-tight">
              Ready to Transform Your Outdoor Space?
            </h3>
            <p className="text-xs sm:text-sm text-[#c2d9cc] leading-relaxed">
              Book an on-site evaluation with our principal landscape designer. We survey soil depth, sunlight exposure, irrigation layout, and provide a tailored 3D master plan.
            </p>

            <div className="pt-4 space-y-2 text-xs text-[#d3e5dc]">
              <p>📍 Available across Gujarat & West India</p>
              <p>📞 Direct Architect Hotline: 9265706952</p>
              <p>⏱ Site visits scheduled within 48 hours</p>
            </div>
          </div>

          <div className="lg:col-span-7">
            {formSubmitted ? (
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 text-center space-y-4 border border-white/20">
                <div className="w-12 h-12 rounded-full bg-emerald-400 text-[#1b382b] flex items-center justify-center mx-auto">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <h4 className="font-serif text-2xl font-bold text-white">
                  Enquiry Received!
                </h4>
                <p className="text-xs text-[#d3e5dc] max-w-md mx-auto">
                  Thank you, <strong>{customerName}</strong>. Our landscape team will call you at <strong>{phone}</strong> to coordinate the site survey.
                </p>
                <button
                  onClick={handleWhatsAppQuote}
                  className="px-5 py-2.5 bg-emerald-400 hover:bg-emerald-300 text-[#14261d] text-xs font-bold rounded-xl transition-colors inline-flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Send Fast Note on WhatsApp</span>
                </button>
              </div>
            ) : (
              <form onSubmit={handleEnquirySubmit} className="bg-white rounded-2xl p-6 sm:p-8 text-[#14261d] space-y-4 shadow-lg">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#14261d] mb-1">Your Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Priyesh Shah"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#14261d] mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 9265706952"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#14261d] mb-1">Service Type</label>
                    <select
                      value={serviceType}
                      onChange={(e) => setServiceType(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    >
                      <option value="Terrace and Rooftop Gardens">Terrace and Rooftop Gardens</option>
                      <option value="Residential Villa Landscaping">Residential Villa Landscaping</option>
                      <option value="Commercial & Office Greenery">Commercial & Office Greenery</option>
                      <option value="Lawn Installation & Turf">Lawn Installation & Turf</option>
                      <option value="Vertical Living Walls">Vertical Living Walls</option>
                      <option value="Farmhouse Master Planning">Farmhouse Master Planning</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#14261d] mb-1">City / Location *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Satellite, Ahmedabad"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#14261d] mb-1">Project Details / Area Estimate</label>
                  <textarea
                    rows={2}
                    placeholder="Approximate area in sq. ft., current site condition, design preferences..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>

                <div className="pt-1 flex flex-col sm:flex-row items-center gap-3">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full sm:flex-1 py-3 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSubmitting ? 'Sending Request...' : 'Submit Landscape Enquiry'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleWhatsAppQuote}
                    className="w-full sm:w-auto px-4 py-3 bg-[#e8f5ec] hover:bg-[#d6eedd] text-[#165330] font-semibold rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <MessageCircle className="w-4 h-4 text-emerald-700" />
                    <span>WhatsApp Quote</span>
                  </button>
                </div>
              </form>
            )}
          </div>

        </div>
      </div>
    </section>
  );
};

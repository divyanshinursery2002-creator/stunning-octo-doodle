import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Phone, MessageCircle, Instagram, MapPin, Mail, Clock, Send, CheckCircle2, Copy, Check, QrCode } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { settings, addEnquiry, openWhatsAppChat } = useApp();

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [serviceType, setServiceType] = useState('Plant Purchase / Availability');
  const [location, setLocation] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [copiedUpi, setCopiedUpi] = useState(false);

  const upiId = settings.upiDetails?.upiId || 'rajkumarrc528389-1@okaxis';
  const payeeName = settings.upiDetails?.payeeName || 'RAJKUMAR CHAUHAN (MR CHAUHAN)';
  const qrImage = settings.upiDetails?.qrCodeImage || '/assets/aistudio/GooglePay_QR__2__08e43f63.png';

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone) {
      alert('Please fill in your name and phone number.');
      return;
    }

    setLoading(true);
    try {
      await addEnquiry({
        customerName,
        phone,
        email,
        serviceType,
        location: location || 'Direct Website Contact',
        message: message || 'Customer reached out via contact page form.',
      });
      setSubmitted(true);
    } catch (_e) {
      alert('Error sending message. Please reach us via WhatsApp or Phone directly.');
    } finally {
      setLoading(false);
    }
  };

  const handleWhatsAppDirect = () => {
    const text = `Hi Divyanshi Nursery! My name is ${customerName || 'Customer'}. I would like to get information regarding ${serviceType}.`;
    openWhatsAppChat(text);
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      {/* Page Header */}
      <div className="max-w-3xl mb-12">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#3d654d] mb-2">
          <span>Get In Touch</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#14261d] tracking-tight">
          Visit Us or Reach Out Directly
        </h2>
        <p className="mt-3 text-base text-[#466152] leading-relaxed">
          Whether you need a single indoor plant, custom decorative ceramic pots, seasonal lawn rejuvenation, or a turnkey terrace landscape quote — we are here to assist.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
        
        {/* Left Column: Direct Business Coordinates */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#ded8cb] shadow-xs space-y-6">
            <h3 className="font-serif text-xl font-bold text-[#14261d]">
              {settings.businessName}
            </h3>

            {/* Click to Call Action Block */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] uppercase tracking-wider text-[#637d6f] font-semibold block">
                  Direct Phone Call
                </span>
                <a
                  href={`tel:${settings.phone}`}
                  className="font-mono text-lg font-bold text-[#14261d] hover:text-[#2d5a3f] transition-colors tabular-nums"
                >
                  +91 {settings.phone}
                </a>
                <p className="text-[11px] text-[#718c7e] mt-0.5">Mon–Sun from 8:00 AM – 8:00 PM</p>
              </div>
            </div>

            {/* WhatsApp Chat Action Block */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#e8f5ec] text-emerald-700 flex items-center justify-center shrink-0">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] uppercase tracking-wider text-[#637d6f] font-semibold block">
                  Instant WhatsApp Chat
                </span>
                <button
                  onClick={() => openWhatsAppChat()}
                  className="text-sm font-bold text-emerald-800 hover:text-emerald-900 underline flex items-center gap-1.5 mt-0.5 cursor-pointer"
                >
                  <span>Chat on WhatsApp (+91 {settings.whatsapp})</span>
                </button>
                <p className="text-[11px] text-[#718c7e] mt-0.5">Instant photos, plant stock & pricing quotes</p>
              </div>
            </div>

            {/* Instagram Profile Action Block */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#fdf2f4] text-[#d62976] flex items-center justify-center shrink-0">
                <Instagram className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] uppercase tracking-wider text-[#637d6f] font-semibold block">
                  Instagram
                </span>
                <a
                  href={`https://instagram.com/${settings.instagram.replace('@', '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sm font-bold text-[#14261d] hover:text-[#d62976] transition-colors block mt-0.5"
                >
                  {settings.instagram}
                </a>
                <p className="text-[11px] text-[#718c7e] mt-0.5">Daily nursery stories, plant reels & new arrivals</p>
              </div>
            </div>

            {/* Nursery Address */}
            <div className="flex items-start gap-4 pt-2 border-t border-[#f0ebe0]">
              <div className="w-10 h-10 rounded-xl bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] uppercase tracking-wider text-[#637d6f] font-semibold block">
                  Nursery Location
                </span>
                <p className="text-xs text-[#2b4436] font-medium leading-relaxed mt-0.5">
                  {settings.address}
                </p>
              </div>
            </div>

            {/* Visiting Hours */}
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] uppercase tracking-wider text-[#637d6f] font-semibold block">
                  Open 7 Days a Week
                </span>
                <p className="text-xs text-[#2b4436] font-medium leading-relaxed mt-0.5">
                  8:00 AM – 8:00 PM (Including Sunday)
                </p>
              </div>
            </div>
          </div>

          {/* Quick Action Button Strip */}
          <div className="grid grid-cols-2 gap-3">
            <a
              href={`tel:${settings.phone}`}
              className="py-3 px-4 bg-[#1b382b] hover:bg-[#254d3b] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span>Call 9265706952</span>
            </a>

            <button
              onClick={() => openWhatsAppChat()}
              className="py-3 px-4 bg-[#156e3b] hover:bg-[#115a30] text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Chat</span>
            </button>
          </div>

          {/* Direct Google Pay & UPI Payment Card */}
          <div className="bg-white rounded-2xl p-5 border-2 border-[#1b382b]/20 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#f0ebe0]">
              <div className="flex items-center gap-2">
                <QrCode className="w-4 h-4 text-[#1b382b]" />
                <h4 className="font-serif text-sm font-bold text-[#14261d]">
                  Direct UPI & Google Pay
                </h4>
              </div>
              <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                Verified Merchant
              </span>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-28 h-28 rounded-xl bg-[#f8f9fa] border border-stone-200 p-1 shrink-0 overflow-hidden shadow-xs flex items-center justify-center">
                <img
                  src={qrImage}
                  alt="Google Pay QR Code"
                  className="w-full h-full object-contain"
                />
              </div>

              <div className="space-y-1.5 min-w-0 flex-1">
                <p className="text-xs font-bold text-[#14261d] truncate">
                  {payeeName}
                </p>
                <div className="p-1.5 bg-[#f0f4f1] rounded-lg border border-[#d2e2d6] flex items-center justify-between">
                  <span className="font-mono text-[11px] font-bold text-[#1b382b] truncate select-all">
                    {upiId}
                  </span>
                  <button
                    onClick={handleCopyUpi}
                    className="p-1 text-[#2d5a3f] hover:text-[#1b382b] transition-colors shrink-0 cursor-pointer"
                    title="Copy UPI ID"
                  >
                    {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-[10px] text-[#6b8577]">
                  Scan with GPay, PhonePe, or Paytm for plant orders & service bookings.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Contact Form & Google Maps Preview */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-2xl p-6 sm:p-8 border border-[#ded8cb] shadow-xs">
            <h3 className="font-serif text-xl font-bold text-[#14261d] mb-1">
              Send an Enquiry
            </h3>
            <p className="text-xs text-[#526d5e] mb-6">
              Fill out this form and our nursery manager will call you back within 2 hours.
            </p>

            {submitted ? (
              <div className="bg-[#eef5f0] border border-[#cbe4d2] rounded-xl p-6 text-center space-y-3">
                <CheckCircle2 className="w-10 h-10 text-emerald-700 mx-auto" />
                <h4 className="font-serif text-lg font-bold text-[#14261d]">
                  Message Dispatched Successfully!
                </h4>
                <p className="text-xs text-[#3a5847] max-w-sm mx-auto">
                  Thank you, <strong>{customerName}</strong>. We have logged your request regarding <em>{serviceType}</em> and will reach out to <strong>{phone}</strong> promptly.
                </p>
                <div className="pt-2">
                  <button
                    onClick={handleWhatsAppDirect}
                    className="px-4 py-2 bg-emerald-700 text-white rounded-lg text-xs font-semibold hover:bg-emerald-800 transition-colors inline-flex items-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Also open in WhatsApp</span>
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-[#14261d] mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ramesh Patel"
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#14261d] mb-1">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      placeholder="e.g. 9265706952"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-semibold text-[#14261d] mb-1">Email Address</label>
                    <input
                      type="email"
                      placeholder="name@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-[#14261d] mb-1">Enquiry Regarding</label>
                    <select
                      value={serviceType}
                      onChange={(e) => setServiceType(e.target.value)}
                      className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                    >
                      <option value="Plant Purchase / Availability">Plant Purchase / Availability</option>
                      <option value="Ceramic Pots & Planters">Ceramic Pots & Planters</option>
                      <option value="Garden Maintenance (AMC)">Garden Maintenance (AMC)</option>
                      <option value="Terrace & Rooftop Landscaping">Terrace & Rooftop Landscaping</option>
                      <option value="Lawn Care & Grass Supply">Lawn Care & Grass Supply</option>
                      <option value="Vertical Green Wall Consultation">Vertical Green Wall Consultation</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Area / City Location</label>
                  <input
                    type="text"
                    placeholder="e.g. Bopal, Ahmedabad"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Your Message or Requirements</label>
                  <textarea
                    rows={3}
                    placeholder="Tell us what you're looking for..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-xl text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                    <span>{loading ? 'Sending...' : 'Submit Message'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Interactive Google Maps Card */}
          <div className="bg-white rounded-2xl p-4 border border-[#ded8cb] shadow-xs">
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-semibold text-[#14261d] flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-[#2d5a3f]" />
                Nursery Location Map
              </span>
              <a
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(settings.address)}`}
                target="_blank"
                rel="noreferrer"
                className="text-[#2d5a3f] font-semibold hover:underline"
              >
                Open in Google Maps App ↗
              </a>
            </div>

            <div className="relative rounded-xl overflow-hidden aspect-[16/7] bg-[#eef0eb] border border-[#ded8cb]">
              <iframe
                title="Divyanshi Nursery Location"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                loading="lazy"
                src={`https://maps.google.com/maps?q=${encodeURIComponent(
                  settings.address || 'Ahmedabad Botanical Garden'
                )}&t=&z=14&ie=UTF8&iwloc=&output=embed`}
              />
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

import React from 'react';
import { useApp } from '../context/AppContext';
import { Phone, MessageCircle, Instagram, MapPin, Mail, Shield, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  const { settings, setCurrentView, openWhatsAppChat } = useApp();

  return (
    <footer className="bg-[#14261d] text-[#e8f0ec] border-t border-[#234232] pt-14 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* 4-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-12 border-b border-[#234232]">
          
          {/* Column 1: Brand & Coordinates */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              {settings.logoImage ? (
                <img
                  src={settings.logoImage}
                  alt={settings.businessName}
                  className="w-9 h-9 rounded-full object-cover border border-emerald-400/30 bg-white shrink-0"
                />
              ) : (
                <div className="w-9 h-9 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center shrink-0">
                  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-current">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
                  </svg>
                </div>
              )}
              <span className="font-serif text-xl font-bold tracking-tight text-white">
                {settings.businessName}
              </span>
            </div>

            <p className="text-xs text-[#a3c2b2] leading-relaxed">
              "{settings.tagline}" — India's premier botanical nursery specializing in acclimatized indoor plants, designer ceramic pots, lawn care, and bespoke architectural landscaping.
            </p>

            <div className="flex items-center gap-3 pt-1">
              <a
                href={`https://instagram.com/${settings.instagram.replace('@', '')}`}
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-[#d62976] hover:text-white text-emerald-200 flex items-center justify-center transition-colors"
                title="Follow on Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>

              <button
                onClick={() => openWhatsAppChat()}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-emerald-600 hover:text-white text-emerald-200 flex items-center justify-center transition-colors"
                title="Chat on WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </button>

              <a
                href={`tel:${settings.phone}`}
                className="w-8 h-8 rounded-lg bg-white/10 hover:bg-emerald-700 hover:text-white text-emerald-200 flex items-center justify-center transition-colors"
                title="Call Nursery Directly"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider text-emerald-300 font-bold">
              Explore Plants & Pots
            </h4>
            <ul className="space-y-2 text-xs text-[#b8d1c4]">
              <li>
                <button
                  onClick={() => {
                    setCurrentView('plants');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Indoor & Air-Purifying Plants
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('plants');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Flowering & Fruit Varieties
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('pots');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Fluted Ceramic & Concrete Pots
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('pots');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Hanging & Designer Planters
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('plants');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Organic Soil & Vermicompost
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Landscaping Services */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider text-emerald-300 font-bold">
              Services & Projects
            </h4>
            <ul className="space-y-2 text-xs text-[#b8d1c4]">
              <li>
                <button
                  onClick={() => {
                    setCurrentView('maintenance');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Residential Garden Maintenance (AMC)
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('maintenance');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Commercial Office Plant Care
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('landscaping');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Terrace & Rooftop Garden Design
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('landscaping');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Natural Lawn & Turf Installation
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setCurrentView('landscaping');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition-colors"
                >
                  Vertical Living Walls & Facades
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Nursery Contact Hotline */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase tracking-wider text-emerald-300 font-bold">
              Visit & Contact
            </h4>
            <div className="space-y-2 text-xs text-[#b8d1c4]">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{settings.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-white font-mono font-semibold">
                  +91 {settings.phone}
                </a>
              </p>
              <p className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <button onClick={() => openWhatsAppChat()} className="hover:text-white text-left font-semibold">
                  WhatsApp: +91 {settings.whatsapp}
                </button>
              </p>
              <p className="flex items-center gap-2">
                <Instagram className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={`https://instagram.com/${settings.instagram.replace('@', '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-white"
                >
                  {settings.instagram}
                </a>
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar: Copyright & Admin Shortcut */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7d9b8b]">
          <p>© {new Date().getFullYear()} {settings.businessName}. All rights reserved.</p>

          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                setCurrentView('admin');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Portal Login</span>
            </button>
            <span aria-hidden="true">·</span>
            <span>Grow Green, Live Beautiful</span>
          </div>
        </div>

      </div>
    </footer>
  );
};

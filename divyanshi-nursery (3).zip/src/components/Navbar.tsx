import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, Phone, Menu, X, Shield, MessageCircle } from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    settings,
    currentView,
    setCurrentView,
    cartCount,
    setIsCartOpen,
    openWhatsAppChat,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: Array<{ label: string; view: 'home' | 'plants' | 'pots' | 'maintenance' | 'landscaping' | 'contact' }> = [
    { label: 'Home', view: 'home' },
    { label: 'All Plants', view: 'plants' },
    { label: 'Pots & Planters', view: 'pots' },
    { label: 'Garden Maintenance', view: 'maintenance' },
    { label: 'Landscaping & Design', view: 'landscaping' },
    { label: 'Contact', view: 'contact' },
  ];

  const handleNavClick = (view: 'home' | 'plants' | 'pots' | 'maintenance' | 'landscaping' | 'contact' | 'admin') => {
    setCurrentView(view);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#faf9f6]/95 backdrop-blur-md border-b border-[#e7e2d8]">
      {/* Announcement Bar */}
      {settings.announcementBar?.enabled && (
        <div className="bg-[#1b382b] text-[#e8f0ec] text-xs font-medium py-1.5 px-4 text-center tracking-wide flex items-center justify-center gap-4">
          <span className="truncate">{settings.announcementBar.text}</span>
          <a
            href={`tel:${settings.phone}`}
            className="hidden sm:inline-flex items-center gap-1 text-emerald-300 hover:text-emerald-200 underline font-semibold shrink-0"
          >
            <Phone className="w-3 h-3" />
            <span>Call {settings.phone}</span>
          </a>
        </div>
      )}

      {/* Top Bar Contract (Zone 1: Brand — Zone 2: Links — Zone 3: Actions) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-20">
          {/* Zone 1: Brand Wordmark */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2.5 text-left group shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2d5a3f]"
          >
            {settings.logoImage ? (
              <img
                src={settings.logoImage}
                alt={settings.businessName}
                className="w-10 h-10 rounded-full object-cover shadow-sm transition-transform group-hover:scale-105 border border-[#1b382b]/30 bg-white shrink-0"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-[#1b382b] flex items-center justify-center text-[#d2e5d8] shadow-sm transition-transform group-hover:scale-105 shrink-0">
                <svg
                  viewBox="0 0 24 24"
                  className="w-5 h-5 fill-current"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z" />
                </svg>
              </div>
            )}
            <div>
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#1b382b] block leading-none">
                {settings.businessName}
              </span>
              <span className="text-[11px] uppercase tracking-wider text-[#52705f] font-medium block mt-0.5">
                {settings.tagline}
              </span>
            </div>
          </button>

          {/* Zone 2: Navigation Links (Clean Single-Line Typography) */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#3b5446]">
            {navLinks.map((link) => {
              const isActive = currentView === link.view;
              return (
                <button
                  key={link.view}
                  onClick={() => handleNavClick(link.view)}
                  className={`transition-colors whitespace-nowrap py-1 relative hover:text-[#1b382b] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2d5a3f] ${
                    isActive ? 'text-[#1b382b] font-semibold' : ''
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2d5a3f] rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Action & Quick Tools */}
          <div className="flex items-center gap-3 shrink-0">
            {/* WhatsApp Quick Chat */}
            <button
              onClick={() => openWhatsAppChat()}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#1b382b] bg-[#e8f0ec] hover:bg-[#d9e7df] rounded-lg transition-colors whitespace-nowrap"
              title="Chat on WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-700" />
              <span>WhatsApp</span>
            </button>

            {/* Shopping Bag */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-[#1b382b] hover:bg-[#ede8df] rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2d5a3f]"
              aria-label={`View cart with ${cartCount} items`}
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#2d5a3f] text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center tabular-nums shadow-sm">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Admin Control Access */}
            <button
              onClick={() => handleNavClick('admin')}
              className={`p-2 rounded-lg transition-colors text-xs font-medium flex items-center gap-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#2d5a3f] ${
                currentView === 'admin'
                  ? 'bg-[#1b382b] text-white'
                  : 'text-[#446352] hover:bg-[#ede8df]'
              }`}
              title="Admin Control Panel"
            >
              <Shield className="w-4 h-4" />
              <span className="hidden md:inline">Admin</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#1b382b] hover:bg-[#ede8df] rounded-lg transition-colors"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#e7e2d8] bg-[#faf9f6] px-4 pt-3 pb-6 space-y-2 shadow-lg animate-in slide-in-from-top duration-200">
          {navLinks.map((link) => {
            const isActive = currentView === link.view;
            return (
              <button
                key={link.view}
                onClick={() => handleNavClick(link.view)}
                className={`w-full text-left px-3 py-2.5 rounded-lg text-base font-medium transition-colors ${
                  isActive
                    ? 'bg-[#1b382b] text-white'
                    : 'text-[#284334] hover:bg-[#ede8df]'
                }`}
              >
                {link.label}
              </button>
            );
          })}
          <div className="pt-3 border-t border-[#e7e2d8] flex items-center justify-between text-xs text-[#52705f]">
            <span>Direct Call: {settings.phone}</span>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openWhatsAppChat();
              }}
              className="text-emerald-700 font-semibold underline"
            >
              WhatsApp Us
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

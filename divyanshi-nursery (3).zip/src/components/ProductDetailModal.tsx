import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, ShoppingBag, MessageCircle, Sun, Droplets, Gauge, MapPin, CheckCircle, ShieldCheck, Truck, CreditCard } from 'lucide-react';

export const ProductDetailModal: React.FC = () => {
  const { quickViewProduct, setQuickViewProduct, addToCart, openWhatsAppChat } = useApp();
  const [quantity, setQuantity] = useState(1);

  if (!quickViewProduct) return null;

  const product = quickViewProduct;

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity);
    setQuickViewProduct(null);
  };

  const handleWhatsAppEnquiry = () => {
    const text = `Hi Divyanshi Nursery, I would like to order "${product.name}" (Qty: ${quantity}, Price: ₹${product.price * quantity}). Please confirm delivery timeframe and address requirements.`;
    openWhatsAppChat(text);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative bg-white rounded-2xl max-w-3xl w-full overflow-hidden shadow-2xl border border-[#ded8cb] my-8">
        
        {/* Close Button */}
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-white/90 backdrop-blur-sm text-[#1b382b] hover:bg-[#ede8df] flex items-center justify-center transition-colors shadow-sm focus-visible:outline-none"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left: Product Image */}
          <div className="relative bg-[#f5f2eb] aspect-square md:aspect-auto h-full min-h-[340px]">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            {product.inStock && (
              <span className="absolute bottom-4 left-4 px-3 py-1 bg-white/90 backdrop-blur-sm text-xs font-semibold text-[#1b382b] rounded-lg shadow-sm flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                {product.stockCount} units available in nursery
              </span>
            )}
          </div>

          {/* Right: Contiguous Purchase Module */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[85vh] overflow-y-auto">
            <div>
              {/* Category & Botanical Name */}
              <div className="text-xs text-[#52705f] font-medium mb-1">
                <span>{product.category}</span>
                {product.botanicalName && (
                  <span className="italic block mt-0.5 text-[#3b5446]">{product.botanicalName}</span>
                )}
              </div>

              {/* Product Title */}
              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#14261d] leading-tight">
                {product.name}
              </h2>

              {/* Price Block */}
              <div className="mt-3 flex items-baseline gap-3">
                <span className="font-mono text-2xl font-bold text-[#14261d] tabular-nums">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                {product.discountPrice && product.discountPrice > product.price && (
                  <>
                    <span className="font-mono text-sm text-[#8c9e94] line-through tabular-nums">
                      ₹{product.discountPrice.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-emerald-700 font-semibold">
                      Save ₹{(product.discountPrice - product.price).toLocaleString('en-IN')}
                    </span>
                  </>
                )}
              </div>

              {/* Description */}
              <p className="mt-4 text-sm text-[#3e5649] leading-relaxed">
                {product.description}
              </p>

              {/* Care Guide Matrix */}
              {product.careInstructions && (
                <div className="mt-5 p-4 bg-[#f8f6f0] rounded-xl border border-[#ece6d9] space-y-2.5 text-xs text-[#2e4739]">
                  <p className="font-bold text-[#1b382b] uppercase tracking-wider text-[11px]">
                    Nursery Care Instructions
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div className="flex items-start gap-2">
                      <Sun className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block text-[#152a1f]">Light:</span>
                        <span className="text-[#516b5c]">{product.careInstructions.sunlight}</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <Droplets className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block text-[#152a1f]">Water:</span>
                        <span className="text-[#516b5c]">{product.careInstructions.watering}</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <Gauge className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block text-[#152a1f]">Difficulty:</span>
                        <span className="text-[#516b5c]">{product.careInstructions.maintenance} Maintenance</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold block text-[#152a1f]">Placement:</span>
                        <span className="text-[#516b5c]">{product.careInstructions.placement}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Pot Specifications if applicable */}
              {product.isPot && (
                <div className="mt-3 text-xs text-[#446352] flex items-center gap-3">
                  {product.potMaterial && <span>Material: <strong>{product.potMaterial}</strong></span>}
                  {product.potSize && <span>Size: <strong>{product.potSize}</strong></span>}
                </div>
              )}
            </div>

            {/* Quantity & Action Buttons */}
            <div className="mt-6 pt-5 border-t border-[#ede7dc] space-y-3">
              {/* Quantity Stepper */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#1b382b]">Quantity:</span>
                <div className="flex items-center border border-[#d3ccbe] rounded-lg overflow-hidden bg-white">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 text-sm text-[#1b382b] hover:bg-[#ede8df] transition-colors"
                  >
                    -
                  </button>
                  <span className="px-4 py-1 text-xs font-bold font-mono text-[#1b382b] tabular-nums">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 text-sm text-[#1b382b] hover:bg-[#ede8df] transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  onClick={handleAddToCart}
                  className="py-3 px-4 bg-[#ede8df] hover:bg-[#ded6c7] text-[#1b382b] text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add to Bag</span>
                </button>

                <button
                  onClick={handleBuyNow}
                  className="py-3 px-4 bg-[#1b382b] hover:bg-[#254d3b] text-white text-xs font-semibold rounded-xl flex items-center justify-center transition-colors cursor-pointer"
                >
                  Order Now
                </button>
              </div>

              {/* WhatsApp Enquiry Button */}
              <button
                onClick={handleWhatsAppEnquiry}
                className="w-full py-2.5 px-4 bg-[#e8f5ec] hover:bg-[#d6eedd] text-[#165330] text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 text-emerald-700" />
                <span>Enquire via WhatsApp</span>
              </button>

              <div className="pt-2 flex flex-col items-center gap-1.5 text-[11px] text-[#6b8577]">
                <div className="flex items-center gap-1.5 text-stone-600 bg-stone-100/90 px-3 py-1 rounded-md text-[10px] font-medium border border-stone-200">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-700" />
                  <span className="text-emerald-900 font-bold">100% Secure Online Payment (Google Pay / UPI)</span>
                </div>
                <div className="flex items-center justify-center gap-4">
                  <span className="flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5" /> Fast Safe Delivery
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Healthy Plant Promise
                  </span>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};

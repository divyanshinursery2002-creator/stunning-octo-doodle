import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Check, Calendar, ArrowRight, ShieldCheck, Sparkles, Scissors, Bug, Droplet, Sprout } from 'lucide-react';

export const MaintenanceSection: React.FC = () => {
  const { services, setServiceBookingModal, openWhatsAppChat } = useApp();

  // Slider or toggle for Before/After Garden Transformation
  const [sliderPosition, setSliderPosition] = useState(50);

  const maintenanceServices = services.filter((s) => s.category === 'maintenance');

  const maintenanceOfferings = [
    {
      title: 'Home Garden Maintenance',
      desc: 'Regular pruning, soil conditioning, and wellness checks for private residence gardens and villa greenery.',
      icon: Sprout,
    },
    {
      title: 'Office & Commercial Greenery',
      desc: 'Indoor plant health care, leaf cleaning, and timely replacement for corporate offices, reception desks, and IT parks.',
      icon: Sparkles,
    },
    {
      title: 'Lawn Care & Grass Treatment',
      desc: 'Mowing, selective weed eradication, top-dressing with sand/compost, and mechanical aeration.',
      icon: Scissors,
    },
    {
      title: 'Plant Pruning & Shaping',
      desc: 'Horticultural canopy trimming, deadheading blooms, hedge shaping, and bonsai maintenance.',
      icon: Scissors,
    },
    {
      title: 'Organic Fertilization & Nutrition',
      desc: 'Custom blends of vermicompost, bone meal, seaweed extract, and neem cake for robust root systems.',
      icon: Droplet,
    },
    {
      title: 'Pest & Fungus Management',
      desc: 'Natural preventative bio-sprays against mealybugs, aphids, spider mites, and root rot pathogens.',
      icon: Bug,
    },
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
      {/* Page Header */}
      <div className="max-w-3xl mb-12">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#3d654d] mb-2">
          <span>Expert Horticultural Care</span>
        </div>
        <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#14261d] tracking-tight">
          Professional Garden Maintenance Services
        </h2>
        <p className="mt-3 text-base text-[#466152] leading-relaxed">
          From residential balconies to expansive commercial landscapes, our skilled horticulturists ensure your plants stay verdant, healthy, and pest-free throughout every season.
        </p>
      </div>

      {/* 6 Core Maintenance Disciplines */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
        {maintenanceOfferings.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className="p-6 bg-white rounded-2xl border border-[#ded8cb] hover:border-[#1b382b]/50 hover:shadow-md transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center mb-4 group-hover:bg-[#1b382b] group-hover:text-emerald-300 transition-colors">
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="font-serif text-lg font-bold text-[#14261d] mb-2">
                {item.title}
              </h3>
              <p className="text-xs text-[#526d5e] leading-relaxed">
                {item.desc}
              </p>
            </div>
          );
        })}
      </div>

      {/* Interactive Before & After Garden Transformation */}
      <div className="bg-[#ede8df] rounded-3xl p-6 sm:p-10 mb-16 border border-[#ded8cb]">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#385945]">
              Real Transformation Results
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#14261d]">
              Witness the Divyanshi Difference
            </h3>
            <p className="text-xs sm:text-sm text-[#4f6758] leading-relaxed">
              Drag the interactive slider to compare a neglected overgrown garden bed with its restored state after our 4-week AMC revitalization treatment.
            </p>
            <div className="pt-2">
              <button
                onClick={() => setServiceBookingModal({ isOpen: true, serviceTitle: 'Garden Restoration & AMC' })}
                className="px-5 py-3 bg-[#1b382b] hover:bg-[#254d3b] text-white text-xs font-semibold rounded-xl transition-all shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Garden Assessment</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-7">
            {/* Interactive Before/After Split Viewer */}
            <div className="relative rounded-2xl overflow-hidden aspect-[16/10] select-none shadow-lg border border-white/60">
              {/* After Image (Background) */}
              <img
                src="/src/assets/images/hero_botanical_nursery_1793198790963.jpg"
                alt="After professional garden maintenance"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <span className="absolute top-3 right-3 px-2.5 py-1 bg-[#1b382b]/80 backdrop-blur-sm text-white text-[11px] font-semibold rounded-md uppercase tracking-wider">
                After Divyanshi Care
              </span>

              {/* Before Image (Clipped Foreground) */}
              <div
                className="absolute inset-y-0 left-0 overflow-hidden"
                style={{ width: `${sliderPosition}%` }}
              >
                <img
                  src="https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80"
                  alt="Before maintenance"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-[800px] max-w-none h-full object-cover"
                  style={{ width: '100%', minWidth: '600px' }}
                />
                <span className="absolute top-3 left-3 px-2.5 py-1 bg-black/70 backdrop-blur-sm text-white text-[11px] font-semibold rounded-md uppercase tracking-wider">
                  Before Treatment
                </span>
              </div>

              {/* Vertical Divider Line with Handle */}
              <div
                className="absolute inset-y-0 w-1 bg-white shadow-xl cursor-ew-resize flex items-center justify-center"
                style={{ left: `${sliderPosition}%` }}
              >
                <div className="w-7 h-7 rounded-full bg-white text-[#1b382b] shadow-md flex items-center justify-center text-[10px] font-bold">
                  ↔
                </div>
              </div>

              {/* Invisible range slider overlay */}
              <input
                type="range"
                min="0"
                max="100"
                value={sliderPosition}
                onChange={(e) => setSliderPosition(Number(e.target.value))}
                className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full"
                aria-label="Before after image comparison slider"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Regular Maintenance Packages (AMC) */}
      <div>
        <div className="text-center max-w-xl mx-auto mb-10">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
            Annual Maintenance Contracts
          </span>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-[#14261d] mt-1">
            Choose Your Garden Care Plan
          </h3>
          <p className="text-xs text-[#52705f] mt-2">
            Scheduled horticulturist visits tailored for bungalows, penthouses, and corporate premises.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {maintenanceServices.map((pkg) => (
            <div
              key={pkg.id}
              className={`rounded-2xl p-6 sm:p-7 flex flex-col justify-between transition-all bg-white border ${
                pkg.popular
                  ? 'border-[#1b382b] ring-2 ring-[#1b382b]/15 shadow-md relative'
                  : 'border-[#ded8cb] hover:border-[#1b382b]/40'
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-3 left-6 px-3 py-0.5 bg-[#1b382b] text-emerald-200 text-[10px] font-bold uppercase tracking-wider rounded-md">
                  Most Popular Plan
                </div>
              )}

              <div>
                <h4 className="font-serif text-xl font-bold text-[#14261d]">
                  {pkg.title}
                </h4>
                <p className="text-xs text-[#5a7667] mt-1">
                  {pkg.subtitle}
                </p>

                <div className="mt-5 mb-6">
                  <span className="text-xs text-[#6e8a7b] block">Starting from</span>
                  <div className="flex items-baseline gap-1 mt-0.5">
                    <span className="font-mono text-3xl font-bold text-[#14261d] tabular-nums">
                      ₹{pkg.priceStartingFrom.toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs text-[#6e8a7b]">/{pkg.pricingUnit}</span>
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t border-[#f0ebe0]">
                  {pkg.features.map((feat, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-[#355140]">
                      <Check className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-[#f0ebe0] space-y-2">
                <button
                  onClick={() => setServiceBookingModal({ isOpen: true, serviceTitle: pkg.title })}
                  className={`w-full py-3 px-4 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    pkg.popular
                      ? 'bg-[#1b382b] hover:bg-[#264b3a] text-white shadow-xs'
                      : 'bg-[#ede8df] hover:bg-[#ded7c7] text-[#1b382b]'
                  }`}
                >
                  <span>Book This Service</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    openWhatsAppChat(
                      `Hello Divyanshi Nursery, I am interested in the "${pkg.title}" maintenance package. Please share the visit schedule and quote.`
                    );
                  }}
                  className="w-full py-2 text-center text-[11px] text-[#2d5a3f] font-semibold hover:underline"
                >
                  Quick Enquiry on WhatsApp
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

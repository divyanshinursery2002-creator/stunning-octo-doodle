import React from 'react';
import { useApp } from '../context/AppContext';
import { Star, Quote, CheckCircle2 } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const { testimonials } = useApp();

  return (
    <section className="bg-[#ede8df] py-14 lg:py-20 border-y border-[#ded8cb]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
            Client Endorsements & Proof
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#14261d] mt-1">
            Trusted by Plant Lovers & Homeowners
          </h2>
          <p className="text-xs sm:text-sm text-[#4e6859] mt-2">
            Read what our clients in Ahmedabad and across Gujarat say about our nursery health standards and landscaping execution.
          </p>
        </div>

        {/* Testimonials 3-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-6 sm:p-7 border border-[#ded8cb] shadow-xs flex flex-col justify-between"
            >
              <div>
                {/* 5-Star Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>

                {/* Quote Text */}
                <p className="text-xs sm:text-sm text-[#2f493b] leading-relaxed italic">
                  "{item.reviewText}"
                </p>
              </div>

              {/* Author & Context Attribution */}
              <div className="mt-6 pt-4 border-t border-[#f0ebe0] flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-xs text-[#14261d] flex items-center gap-1.5">
                    <span>{item.authorName}</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                  </h4>
                  <p className="text-[11px] text-[#5e7d6b]">{item.location}</p>
                </div>

                <div className="text-right">
                  <span className="text-[11px] font-medium text-[#1b382b] bg-[#eef5f0] px-2 py-0.5 rounded-md block">
                    {item.serviceUsed}
                  </span>
                  <span className="text-[10px] text-[#7d9386] mt-0.5 block">{item.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Trash2,
  ShoppingBag,
  ArrowRight,
  CheckCircle,
  MessageCircle,
  Truck,
  Copy,
  Check,
  QrCode,
  ExternalLink,
  ShieldCheck,
  Smartphone,
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    updateCartQuantity,
    removeFromCart,
    cartTotal,
    clearCart,
    placeOrder,
    openWhatsAppChat,
    settings,
  } = useApp();

  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [pincode, setPincode] = useState('');
  const [upiTransactionId, setUpiTransactionId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedOrderNumber, setCompletedOrderNumber] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);

  if (!isCartOpen) return null;

  const deliveryCharge = cartTotal >= 999 ? 0 : 99;
  const grandTotal = cartTotal + deliveryCharge;

  const upiId = settings.upiDetails?.upiId || 'rajkumarrc528389-1@okaxis';
  const payeeName = settings.upiDetails?.payeeName || 'RAJKUMAR CHAUHAN (MR CHAUHAN)';
  const qrImage = settings.upiDetails?.qrCodeImage || '/assets/aistudio/GooglePay_QR__2__08e43f63.png';

  const upiDeepLink = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(payeeName)}&am=${grandTotal}&cu=INR&tn=${encodeURIComponent('Divyanshi Nursery Plants')}`;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !phone || !address || !city) {
      alert('Please fill in your name, phone number, and full delivery address.');
      return;
    }

    setIsSubmitting(true);
    try {
      const order = await placeOrder({
        customerName,
        phone,
        address,
        city,
        pincode,
        items: cart,
        totalAmount: grandTotal,
        paymentMethod: 'Online Payment (Google Pay / UPI)',
        upiTransactionId: upiTransactionId || undefined,
      });

      setCompletedOrderNumber(order.id);
      setStep('success');
    } catch (_err) {
      alert('Could not submit order. Please check connection.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSendOrderToWhatsApp = () => {
    const itemsSummary = cart
      .map((item) => `- ${item.name} (x${item.quantity}) = ₹${item.price * item.quantity}`)
      .join('\n');

    const utrLine = upiTransactionId ? `\n*UPI UTR / Ref No:* ${upiTransactionId}` : '';

    const msg = `🌿 *New Online Plant Order - Divyanshi Nursery*\nOrder Ref: #${completedOrderNumber}\nCustomer: ${customerName}\nPhone: ${phone}\nAddress: ${address}, ${city} - ${pincode}\n*Payment Mode:* Online Payment (Google Pay / UPI)\n*Paid to:* ${payeeName} (${upiId})${utrLine}\n\n*Items Ordered:*\n${itemsSummary}\n\n*Total Amount:* ₹${grandTotal}\n\nI have submitted my order and paid via Google Pay / UPI. Please confirm my dispatch!`;

    openWhatsAppChat(msg);
  };

  const handleClose = () => {
    setIsCartOpen(false);
    if (step === 'success') {
      setStep('cart');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/50 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div className="bg-[#faf9f6] w-full max-w-md h-full flex flex-col shadow-2xl border-l border-[#e7e2d8] animate-in slide-in-from-right duration-300">
        
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-[#e7e2d8] flex items-center justify-between bg-white">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#1b382b]" />
            <h2 className="font-serif text-lg font-bold text-[#14261d]">
              {step === 'cart' && 'Your Shopping Bag'}
              {step === 'checkout' && 'Online Checkout (UPI / GPay)'}
              {step === 'success' && 'Order Confirmed'}
            </h2>
          </div>
          <button
            onClick={handleClose}
            className="p-1.5 text-[#5e7d6b] hover:text-[#14261d] hover:bg-[#ede8df] rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5">
          {step === 'cart' && (
            <>
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-[#5e7d6b] py-16">
                  <div className="w-16 h-16 rounded-full bg-[#ede8df] flex items-center justify-center mb-4 text-[#1b382b]">
                    <ShoppingBag className="w-8 h-8 stroke-1" />
                  </div>
                  <p className="font-serif text-lg font-bold text-[#1b382b]">Your bag is empty</p>
                  <p className="text-xs text-[#6e8a7b] mt-1 max-w-xs">
                    Explore our healthy indoor plants, designer pots, and organic gardening supplies.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.productId}
                      className="flex items-center gap-3.5 p-3 bg-white rounded-xl border border-[#ece6d9]"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded-lg object-cover bg-[#f4f0e6] shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-semibold text-[#14261d] truncate">
                          {item.name}
                        </h4>
                        <p className="text-xs font-mono font-bold text-[#1b382b] mt-0.5 tabular-nums">
                          ₹{item.price.toLocaleString('en-IN')}
                        </p>

                        {/* Quantity Stepper */}
                        <div className="flex items-center gap-2 mt-2">
                          <div className="flex items-center border border-[#d6cfc0] rounded-md bg-white">
                            <button
                              onClick={() => updateCartQuantity(item.productId, item.quantity - 1)}
                              className="px-2 py-0.5 text-xs text-[#1b382b] hover:bg-[#ede8df]"
                            >
                              -
                            </button>
                            <span className="px-2.5 py-0.5 text-xs font-mono font-bold tabular-nums">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateCartQuantity(item.productId, item.quantity + 1)}
                              className="px-2 py-0.5 text-xs text-[#1b382b] hover:bg-[#ede8df]"
                            >
                              +
                            </button>
                          </div>

                          <button
                            onClick={() => removeFromCart(item.productId)}
                            className="p-1 text-[#8b9e93] hover:text-red-600 transition-colors cursor-pointer"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-bold font-mono text-[#14261d] tabular-nums">
                          ₹{(item.price * item.quantity).toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>
                  ))}

                  {/* Free delivery threshold indicator */}
                  <div className="p-3 bg-[#eef5f0] rounded-xl border border-[#d4e5d8] text-xs text-[#204932] flex items-center gap-2">
                    <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>
                      {cartTotal >= 999
                        ? '🎉 You unlocked FREE Home Delivery!'
                        : `Add ₹${(999 - cartTotal).toLocaleString('en-IN')} more for FREE delivery.`}
                    </span>
                  </div>

                  {/* Prepaid Only Notice */}
                  <div className="p-3 bg-[#fdfaf3] rounded-xl border border-[#eedfc1] text-xs text-[#7c561b] flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#a37222] shrink-0" />
                    <span>
                      <strong>100% Online Payment:</strong> All orders are prepaid via Google Pay or UPI for guaranteed fresh plant reservation.
                    </span>
                  </div>
                </div>
              )}
            </>
          )}

          {step === 'checkout' && (
            <form onSubmit={handleCheckoutSubmit} className="space-y-4 text-xs">
              {/* Delivery Details */}
              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Shah"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#d6cfc0] rounded-lg text-sm text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">WhatsApp / Mobile Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9876543210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#d6cfc0] rounded-lg text-sm text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#14261d] mb-1">Delivery Address *</label>
                <textarea
                  required
                  rows={2}
                  placeholder="House/Flat No., Society, Landmark"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#d6cfc0] rounded-lg text-sm text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">City *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ahmedabad / Other"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#d6cfc0] rounded-lg text-sm text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-[#14261d] mb-1">Pincode</label>
                  <input
                    type="text"
                    placeholder="e.g. 380054"
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#d6cfc0] rounded-lg text-sm text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>
              </div>

              {/* Online Payment Method (Google Pay / PhonePe / Paytm / UPI) */}
              <div className="pt-2">
                <div className="p-3 bg-[#eef7f1] rounded-xl border-2 border-[#1b382b] flex items-center justify-between shadow-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-[#1b382b] text-emerald-300 flex items-center justify-center font-bold text-xs shrink-0">
                      ₹
                    </div>
                    <div>
                      <span className="font-bold text-xs text-[#14261d] block">
                        Online Payment (Google Pay / UPI)
                      </span>
                      <span className="text-[11px] text-[#42614e] block">
                        Pay safely with Google Pay, PhonePe, Paytm, or Any UPI App
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-[#1b382b] text-white font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider shrink-0">
                    Online Only
                  </span>
                </div>
              </div>

              {/* Official Google Pay UPI QR Code Box */}
              <div className="p-4 bg-white rounded-2xl border-2 border-[#1b382b]/30 shadow-sm space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-stone-200">
                  <div className="flex items-center gap-2">
                    <QrCode className="w-4 h-4 text-[#1b382b]" />
                    <span className="font-serif font-bold text-xs text-[#14261d]">
                      Scan QR Code to Pay ₹{grandTotal.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                    Official GPay QR
                  </span>
                </div>

                {/* QR Image Display */}
                <div className="flex flex-col items-center justify-center p-2.5 bg-[#f8f9fa] rounded-xl border border-stone-200">
                  <img
                    src={qrImage}
                    alt="Google Pay UPI QR Code - Divyanshi Nursery"
                    className="w-44 h-auto object-contain rounded-lg shadow-xs"
                  />

                  {/* Payee Name */}
                  <p className="text-[11px] font-bold text-[#14261d] mt-2">
                    {payeeName}
                  </p>

                  {/* Amount to Pay */}
                  <p className="text-xs text-[#2d5a3f] font-mono font-bold mt-0.5">
                    Total Amount: ₹{grandTotal.toLocaleString('en-IN')}
                  </p>
                </div>

                {/* Direct App Launch Button on Mobile */}
                <a
                  href={upiDeepLink}
                  className="w-full py-2 px-3 bg-[#e8f5ec] hover:bg-[#d6eedd] text-[#165330] rounded-xl text-xs font-bold flex items-center justify-center gap-2 border border-[#c3decb] transition-colors"
                >
                  <Smartphone className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Tap to Pay Directly with UPI App (Mobile)</span>
                </a>

                {/* 1-Click Copy UPI ID */}
                <div className="flex items-center justify-between p-2.5 bg-[#f0f4f1] rounded-xl border border-[#d2e2d6]">
                  <div>
                    <span className="text-[10px] text-[#5f7a6b] font-medium block">UPI ID:</span>
                    <span className="font-mono text-xs font-bold text-[#1b382b] select-all">
                      {upiId}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="px-2.5 py-1 bg-white hover:bg-stone-100 text-[#1b382b] rounded-lg text-[11px] font-semibold border border-stone-300 flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    {copiedUpi ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy UPI</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Optional UTR / Reference ID Field */}
                <div>
                  <label className="block text-[11px] font-semibold text-[#14261d] mb-1">
                    UPI Transaction / UTR Number (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="Enter 12-digit UPI UTR number if paid"
                    value={upiTransactionId}
                    onChange={(e) => setUpiTransactionId(e.target.value)}
                    className="w-full px-3 py-1.5 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] font-mono focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-sm"
                >
                  {isSubmitting ? 'Confirming Online Order...' : `Complete Order (₹${grandTotal.toLocaleString('en-IN')})`}
                </button>
              </div>
            </form>
          )}

          {step === 'success' && (
            <div className="h-full flex flex-col items-center justify-center text-center py-6">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center mb-3">
                <CheckCircle className="w-7 h-7" />
              </div>
              <h3 className="font-serif text-xl font-bold text-[#14261d]">
                Order Confirmed!
              </h3>
              <p className="text-xs text-[#4f6859] mt-0.5 max-w-xs">
                Thank you, <strong>{customerName}</strong>! Your order reference is{' '}
                <span className="font-mono font-bold text-[#1b382b]">#{completedOrderNumber}</span>.
              </p>

              {/* Display QR Code on Success for quick payment confirmation */}
              <div className="my-4 p-4 bg-white rounded-2xl border-2 border-[#1b382b]/30 shadow-md text-center w-full space-y-2">
                <span className="text-[11px] font-bold text-[#14261d] block">
                  Scan to Complete Payment via Google Pay / UPI
                </span>
                <div className="flex justify-center p-1 bg-[#f8f9fa] rounded-xl border border-stone-200">
                  <img
                    src={qrImage}
                    alt="Google Pay QR Code"
                    className="w-40 h-auto object-contain rounded-lg"
                  />
                </div>
                <div className="flex items-center justify-between text-xs px-2 pt-1">
                  <span className="font-mono font-bold text-[#1b382b]">Total: ₹{grandTotal.toLocaleString('en-IN')}</span>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="text-[#2d5a3f] font-semibold text-[11px] hover:underline"
                  >
                    {copiedUpi ? '✓ UPI ID Copied' : `Copy UPI: ${upiId}`}
                  </button>
                </div>
              </div>

              <div className="my-3 p-3 bg-white rounded-xl border border-[#ded8cb] text-left w-full text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-[#688172]">Total Payable:</span>
                  <span className="font-mono font-bold text-[#14261d]">₹{grandTotal.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#688172]">Payment Mode:</span>
                  <span className="font-semibold text-emerald-800">Online Payment (Google Pay / UPI)</span>
                </div>
                {upiTransactionId && (
                  <div className="flex justify-between">
                    <span className="text-[#688172]">UPI UTR / Ref:</span>
                    <span className="font-mono font-bold text-[#14261d]">{upiTransactionId}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-[#688172]">Deliver to:</span>
                  <span className="text-[#14261d] truncate max-w-[180px]">{address}, {city}</span>
                </div>
              </div>

              {/* Instant WhatsApp Order Dispatch Button */}
              <button
                onClick={handleSendOrderToWhatsApp}
                className="w-full py-3 bg-[#156e3b] hover:bg-[#115a30] text-white font-semibold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 mb-2 cursor-pointer shadow-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send Order & Payment Receipt to WhatsApp</span>
              </button>

              <button
                onClick={handleClose}
                className="text-xs text-[#52705f] hover:underline"
              >
                Continue Shopping
              </button>
            </div>
          )}
        </div>

        {/* Drawer Footer (Summary & Action for 'cart' step) */}
        {step === 'cart' && cart.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-[#e7e2d8] bg-white space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-[#5f7a6b]">
                <span>Items Subtotal:</span>
                <span className="font-mono font-bold text-[#14261d] tabular-nums">
                  ₹{cartTotal.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between text-[#5f7a6b]">
                <span>Doorstep Delivery:</span>
                <span className="font-mono font-bold text-[#14261d] tabular-nums">
                  {deliveryCharge === 0 ? <span className="text-emerald-700">FREE</span> : `₹${deliveryCharge}`}
                </span>
              </div>
              <div className="flex justify-between text-sm font-bold text-[#14261d] pt-2 border-t border-[#f0ebe0]">
                <span>Grand Total:</span>
                <span className="font-mono text-base text-[#1b382b] tabular-nums">
                  ₹{grandTotal.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <button
              onClick={() => setStep('checkout')}
              className="w-full py-3.5 bg-[#1b382b] hover:bg-[#254d3b] text-white font-semibold rounded-xl text-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <span>Proceed to Online Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};

import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext';
import { ProductCard } from './ProductCard';
import { ProductCategory } from '../types';
import { Filter, Search, RotateCcw } from 'lucide-react';

export const PlantsSection: React.FC = () => {
  const {
    products,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
  } = useApp();

  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');
  const [onlyInStock, setOnlyInStock] = useState(false);

  const categories: Array<ProductCategory | 'All'> = [
    'All',
    'Indoor Plants',
    'Air-Purifying Plants',
    'Outdoor Plants',
    'Flowering Plants',
    'Fruit Plants',
    'Ornamental Plants',
    'Succulents and Cacti',
    'Trees and Shrubs',
    'Medicinal Plants',
    'Seeds and Gardening Supplies',
    'Pots and Planters',
    'Garden Accessories',
  ];

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category match
      if (selectedCategory !== 'All' && p.category !== selectedCategory) {
        return false;
      }
      // Search match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(query);
        const matchesBotanical = p.botanicalName?.toLowerCase().includes(query);
        const matchesCategory = p.category.toLowerCase().includes(query);
        const matchesDesc = p.description.toLowerCase().includes(query);
        const matchesTags = p.tags?.some((t) => t.toLowerCase().includes(query));
        if (!matchesName && !matchesBotanical && !matchesCategory && !matchesDesc && !matchesTags) {
          return false;
        }
      }
      // Stock match
      if (onlyInStock && !p.inStock) {
        return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      // Default: featured first, then name
      if (a.featured && !b.featured) return -1;
      if (!a.featured && b.featured) return 1;
      return 0;
    });
  }, [products, selectedCategory, searchQuery, onlyInStock, sortBy]);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14">
      {/* Section Header */}
      <div className="space-y-2 mb-8">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
          <span>Botanical Nursery Catalog</span>
        </div>
        <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#14261d]">
          Explore All Plants & Supplies
        </h2>
        <p className="text-sm text-[#4e6859] max-w-2xl">
          Carefully nurtured nursery plants, certified air-purifiers, fruiting varieties, and organic soil mixes for homes, terraces, and corporate gardens.
        </p>
      </div>

      {/* Category Segmented Filter Bar */}
      <div className="overflow-x-auto pb-2 scrollbar-none mb-6">
        <div className="flex items-center gap-1.5 min-w-max p-1 bg-[#ede8df] rounded-xl">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#1b382b] text-white shadow-xs font-semibold'
                    : 'text-[#385142] hover:text-[#14261d] hover:bg-white/60'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Control Bar: Search Input, In-Stock Toggle & Sort */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8 p-3 bg-white rounded-xl border border-[#ded8cb]">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#607d6c] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Filter plants by name or care requirement..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-[#faf9f6] border border-[#d6cfc0] rounded-lg text-xs text-[#1b382b] placeholder-[#7d9386] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-xs text-[#8ca094] hover:text-[#14261d]"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter Controls Right */}
        <div className="flex items-center gap-4 text-xs text-[#3d5648] shrink-0">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={onlyInStock}
              onChange={(e) => setOnlyInStock(e.target.checked)}
              className="rounded accent-[#1b382b]"
            />
            <span className="font-medium">In Stock Only</span>
          </label>

          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-[#607d6c]" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-[#faf9f6] border border-[#d6cfc0] rounded-lg px-2.5 py-1.5 text-xs text-[#1b382b] focus:outline-none focus:ring-1 focus:ring-[#1b382b]"
            >
              <option value="featured">Featured First</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
            </select>
          </div>
        </div>
      </div>

      {/* Product Results Counter */}
      <div className="flex items-center justify-between text-xs text-[#52705f] mb-6">
        <span>
          Showing <strong className="text-[#14261d] font-mono tabular-nums">{filteredProducts.length}</strong> items
          {selectedCategory !== 'All' && <span> in <em>{selectedCategory}</em></span>}
        </span>
        {(selectedCategory !== 'All' || searchQuery || onlyInStock) && (
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
              setOnlyInStock(false);
            }}
            className="flex items-center gap-1 text-[#2d5a3f] hover:underline font-medium"
          >
            <RotateCcw className="w-3 h-3" />
            Reset all filters
          </button>
        )}
      </div>

      {/* 3-Column / 4-Column Product Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="text-center py-16 bg-white rounded-2xl border border-[#ded8cb] p-8">
          <div className="w-12 h-12 rounded-full bg-[#f0ede6] text-[#4f6b5b] flex items-center justify-center mx-auto mb-3">
            <Search className="w-6 h-6" />
          </div>
          <h3 className="font-serif text-lg font-bold text-[#14261d]">No plants found</h3>
          <p className="text-xs text-[#52705f] mt-1 max-w-sm mx-auto">
            We couldn't find any items matching your selected criteria. Try adjusting the search keywords or resetting category filters.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
              setOnlyInStock(false);
            }}
            className="mt-4 px-4 py-2 bg-[#1b382b] text-white text-xs font-semibold rounded-lg hover:bg-[#254d3b] transition-colors"
          >
            Show All Plants
          </button>
        </div>
      )}
    </section>
  );
};

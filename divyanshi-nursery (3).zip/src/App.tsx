import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { PlantsSection } from './components/PlantsSection';
import { PotsSection } from './components/PotsSection';
import { MaintenanceSection } from './components/MaintenanceSection';
import { LandscapingSection } from './components/LandscapingSection';
import { ContactSection } from './components/ContactSection';
import { AdminPanel } from './components/AdminPanel';
import { CartDrawer } from './components/CartDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ServiceBookingModal } from './components/ServiceBookingModal';
import { TestimonialsSection } from './components/TestimonialsSection';
import { Footer } from './components/Footer';
import { MessageCircle, ArrowRight, Sparkles, Sprout, Wrench, ShieldCheck, Heart } from 'lucide-react';

const MainContent: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    products,
    setSelectedCategory,
    openWhatsAppChat,
  } = useApp();

  // Featured Plants on Homepage
  const featuredPlants = products.filter((p) => p.featured).slice(0, 4);
  const latestArrivals = products.slice(0, 4);

  return (
    <div className="min-h-screen flex flex-col bg-[#faf9f6]">
      <Navbar />

      <main className="flex-1">
        {currentView === 'home' && (
          <>
            {/* 1. Hero Banner */}
            <Hero />

            {/* 2. Featured Plants Section */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
                    Curated Nursery Specimens
                  </span>
                  <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#14261d] mt-1">
                    Featured Plants & Bestsellers
                  </h2>
                </div>

                <button
                  onClick={() => {
                    setSelectedCategory('All');
                    setCurrentView('plants');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-xs font-semibold text-[#1b382b] hover:text-[#2d5a3f] flex items-center gap-1.5 self-start sm:self-auto group"
                >
                  <span>Explore Full Collection</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredPlants.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </section>

            {/* 3. Services & Landscaping Teaser Banner */}
            <section className="bg-[#ede8df] py-14 border-y border-[#ded8cb]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
                  
                  {/* Maintenance Teaser Card */}
                  <div className="bg-white rounded-3xl p-6 sm:p-8 border border-[#ded8cb] flex flex-col justify-between shadow-xs">
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-[#e8f0ec] text-[#1b382b] flex items-center justify-center mb-4">
                        <Wrench className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
                        Horticulture AMC
                      </span>
                      <h3 className="font-serif text-2xl font-bold text-[#14261d] mt-1 mb-2">
                        Professional Garden Maintenance
                      </h3>
                      <p className="text-xs sm:text-sm text-[#4f6758] leading-relaxed">
                        Keep your home or commercial garden thriving with scheduled expert visits. We provide natural organic fertilization, canopy pruning, lawn mowing, and pest prevention.
                      </p>
                    </div>

                    <div className="pt-6">
                      <button
                        onClick={() => {
                          setCurrentView('maintenance');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="px-5 py-2.5 bg-[#1b382b] hover:bg-[#254d3b] text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-2"
                      >
                        <span>View Maintenance Plans</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Landscaping Teaser Card */}
                  <div className="bg-[#1b382b] text-white rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-md">
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-white/10 text-emerald-300 flex items-center justify-center mb-4">
                        <Sprout className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-semibold uppercase tracking-wider text-emerald-300">
                        Turnkey Architecture
                      </span>
                      <h3 className="font-serif text-2xl font-bold mt-1 mb-2">
                        Landscaping & Terrace Garden Design
                      </h3>
                      <p className="text-xs sm:text-sm text-[#c5dbcf] leading-relaxed">
                        From barren rooftop concrete to luxury tropical sanctuaries. We design and build wooden pergolas, Korean carpet lawns, and automated vertical living bio-walls.
                      </p>
                    </div>

                    <div className="pt-6 flex items-center gap-3">
                      <button
                        onClick={() => {
                          setCurrentView('landscaping');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="px-5 py-2.5 bg-emerald-400 hover:bg-emerald-300 text-[#14261d] text-xs font-bold rounded-xl transition-colors flex items-center gap-2"
                      >
                        <span>Explore Landscape Portfolio</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* 4. Designer Pots & Planters Spotlight */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
                <div>
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#3d654d]">
                    Handcrafted Vessels
                  </span>
                  <h2 className="font-serif text-2xl sm:text-4xl font-bold text-[#14261d] mt-1">
                    Designer Pots & Ceramic Planters
                  </h2>
                </div>

                <button
                  onClick={() => {
                    setCurrentView('pots');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-xs font-semibold text-[#1b382b] hover:text-[#2d5a3f] flex items-center gap-1.5 self-start sm:self-auto group"
                >
                  <span>View All Planters</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products
                  .filter((p) => p.category === 'Pots and Planters' || p.isPot)
                  .slice(0, 4)
                  .map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
              </div>
            </section>

            {/* 5. Customer Testimonials */}
            <TestimonialsSection />
          </>
        )}

        {currentView === 'plants' && <PlantsSection />}
        {currentView === 'pots' && <PotsSection />}
        {currentView === 'maintenance' && <MaintenanceSection />}
        {currentView === 'landscaping' && <LandscapingSection />}
        {currentView === 'contact' && <ContactSection />}
        {currentView === 'admin' && <AdminPanel />}
      </main>

      <Footer />

      {/* Slide-out Cart Drawer */}
      <CartDrawer />

      {/* Product Detail Modal */}
      <ProductDetailModal />

      {/* Service Appointment Booking Modal */}
      <ServiceBookingModal />

      {/* Floating Direct WhatsApp Button */}
      <button
        onClick={() => openWhatsAppChat()}
        className="fixed bottom-6 right-6 z-40 bg-[#25D366] hover:bg-[#20ba59] text-white p-3.5 rounded-full shadow-2xl transition-transform hover:scale-110 flex items-center justify-center cursor-pointer group"
        aria-label="Direct WhatsApp Enquiry"
        title="Chat on WhatsApp (+91 9265706952)"
      >
        <MessageCircle className="w-6 h-6 fill-current" />
        <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs transition-all duration-300 ease-in-out text-xs font-bold pl-0 group-hover:pl-2">
          Chat with Us
        </span>
      </button>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}

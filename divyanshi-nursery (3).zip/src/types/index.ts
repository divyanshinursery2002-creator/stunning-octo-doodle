export type ProductCategory =
  | 'Indoor Plants'
  | 'Outdoor Plants'
  | 'Flowering Plants'
  | 'Fruit Plants'
  | 'Air-Purifying Plants'
  | 'Ornamental Plants'
  | 'Succulents and Cacti'
  | 'Trees and Shrubs'
  | 'Medicinal Plants'
  | 'Seeds and Gardening Supplies'
  | 'Pots and Planters'
  | 'Garden Accessories';

export type PotMaterial = 'Ceramic' | 'Terracotta' | 'Cement' | 'Plastic' | 'Hanging' | 'Designer';

export interface Product {
  id: string;
  name: string;
  botanicalName?: string;
  category: ProductCategory;
  price: number;
  discountPrice?: number;
  image: string;
  secondaryImages?: string[];
  description: string;
  careInstructions: {
    sunlight: string;
    watering: string;
    maintenance: 'Low' | 'Moderate' | 'High';
    placement: string;
  };
  inStock: boolean;
  stockCount: number;
  featured?: boolean;
  isPot?: boolean;
  potMaterial?: PotMaterial;
  potSize?: string;
  tags?: string[];
}

export interface ServicePackage {
  id: string;
  title: string;
  category: 'maintenance' | 'landscaping' | 'design';
  subtitle: string;
  description: string;
  priceStartingFrom: number;
  pricingUnit: string;
  features: string[];
  image: string;
  popular?: boolean;
}

export interface LandscapingProject {
  id: string;
  title: string;
  category: string;
  location: string;
  clientType: 'Residential' | 'Commercial' | 'Terrace' | 'Villa';
  areaSize: string;
  description: string;
  beforeImage: string;
  afterImage: string;
  completedYear: string;
  keyHighlights: string[];
}

export interface Enquiry {
  id: string;
  createdAt: string;
  customerName: string;
  phone: string;
  email?: string;
  serviceType: string;
  location: string;
  message: string;
  status: 'New' | 'Contacted' | 'In Progress' | 'Completed';
  notes?: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id: string;
  createdAt: string;
  customerName: string;
  phone: string;
  address: string;
  city: string;
  pincode: string;
  items: OrderItem[];
  totalAmount: number;
  paymentMethod: 'Online Payment (Google Pay / UPI)';
  upiTransactionId?: string;
  status: 'Pending' | 'Confirmed' | 'Dispatched' | 'Delivered' | 'Cancelled';
}

export interface SiteSettings {
  businessName: string;
  tagline: string;
  phone: string;
  whatsapp: string;
  instagram: string;
  email: string;
  address: string;
  googleMapsQuery: string;
  heroHeadline: string;
  heroSubtitle: string;
  heroImage: string;
  logoText: string;
  logoImage?: string;
  announcementBar: {
    enabled: boolean;
    text: string;
  };
  upiDetails?: {
    payeeName: string;
    upiId: string;
    qrCodeImage: string;
  };
}

export interface Testimonial {
  id: string;
  authorName: string;
  location: string;
  rating: number;
  reviewText: string;
  serviceUsed: string;
  date: string;
}

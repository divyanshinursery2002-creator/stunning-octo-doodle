import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { initialProducts, initialServicePackages, initialProjects, initialSiteSettings, initialTestimonials } from './src/data/initialData';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Body parsers with high limit for direct image base64 uploads
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure data folder and public uploads folder exist
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const UPLOADS_DIR = path.join(__dirname, 'public', 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Initialize database if not exists
interface DbSchema {
  products: typeof initialProducts;
  services: typeof initialServicePackages;
  projects: typeof initialProjects;
  settings: typeof initialSiteSettings;
  testimonials: typeof initialTestimonials;
  enquiries: Array<{
    id: string;
    createdAt: string;
    customerName: string;
    phone: string;
    email?: string;
    serviceType: string;
    location: string;
    message: string;
    status: 'New' | 'Contacted' | 'In Progress' | 'Completed';
    notes?: string;
  }>;
  orders: Array<any>;
}

function readDb(): DbSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      // Ensure upiDetails is populated
      if (parsed.settings && !parsed.settings.upiDetails) {
        parsed.settings.upiDetails = initialSiteSettings.upiDetails;
      }
      return parsed;
    }
  } catch (err) {
    console.error('Error reading db.json, returning defaults:', err);
  }

  const defaultDb: DbSchema = {
    products: initialProducts,
    services: initialServicePackages,
    projects: initialProjects,
    settings: initialSiteSettings,
    testimonials: initialTestimonials,
    enquiries: [
      {
        id: 'enq-1',
        createdAt: new Date().toISOString(),
        customerName: 'Rahul Verma',
        phone: '9876543210',
        email: 'rahul.verma@example.com',
        serviceType: 'Terrace Garden Landscaping',
        location: 'Bodakdev, Ahmedabad',
        message: 'Looking for a complete terrace garden makeover with drip irrigation for 1,500 sq ft.',
        status: 'New',
      },
    ],
    orders: [],
  };
  saveDb(defaultDb);
  return defaultDb;
}

function saveDb(data: DbSchema) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving db.json:', err);
  }
}

// Serve uploaded and public assets statically
app.use('/uploads', express.static(UPLOADS_DIR));
app.use('/assets/aistudio', express.static(path.join(__dirname, 'public', 'assets', 'aistudio')));
app.use(express.static(path.join(__dirname, 'public')));

// Direct Image Upload Endpoint
app.post('/api/upload', (req, res) => {
  try {
    const { imageBase64, filename } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'No image data provided' });
    }

    // Match base64 prefix
    const matches = imageBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let buffer: Buffer;
    let extension = '.jpg';

    if (matches && matches.length === 3) {
      const mimeType = matches[1];
      if (mimeType.includes('png')) extension = '.png';
      else if (mimeType.includes('webp')) extension = '.webp';
      else if (mimeType.includes('svg')) extension = '.svg';
      buffer = Buffer.from(matches[2], 'base64');
    } else {
      buffer = Buffer.from(imageBase64, 'base64');
    }

    const safeFilename = `upload_${Date.now()}_${(filename || 'image').replace(/[^a-zA-Z0-9_-]/g, '')}${extension}`;
    const filePath = path.join(UPLOADS_DIR, safeFilename);

    fs.writeFileSync(filePath, buffer);
    const publicUrl = `/uploads/${safeFilename}`;

    return res.json({ success: true, url: publicUrl, filename: safeFilename });
  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ error: 'Failed to process image upload' });
  }
});

// Full state endpoint
app.get('/api/data', (_req, res) => {
  const db = readDb();
  res.json(db);
});

// Products CRUD
app.post('/api/products', (req, res) => {
  const db = readDb();
  const newProduct = {
    ...req.body,
    id: req.body.id || `prod-${Date.now()}`,
  };
  db.products.unshift(newProduct);
  saveDb(db);
  res.status(201).json(newProduct);
});

app.put('/api/products/:id', (req, res) => {
  const db = readDb();
  const index = db.products.findIndex((p) => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Product not found' });
  }
  db.products[index] = { ...db.products[index], ...req.body };
  saveDb(db);
  res.json(db.products[index]);
});

app.delete('/api/products/:id', (req, res) => {
  const db = readDb();
  db.products = db.products.filter((p) => p.id !== req.params.id);
  saveDb(db);
  res.json({ success: true });
});

// Services CRUD
app.post('/api/services', (req, res) => {
  const db = readDb();
  const newService = {
    ...req.body,
    id: req.body.id || `serv-${Date.now()}`,
  };
  db.services.push(newService);
  saveDb(db);
  res.status(201).json(newService);
});

app.put('/api/services/:id', (req, res) => {
  const db = readDb();
  const index = db.services.findIndex((s) => s.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Service not found' });
  }
  db.services[index] = { ...db.services[index], ...req.body };
  saveDb(db);
  res.json(db.services[index]);
});

// Projects CRUD
app.post('/api/projects', (req, res) => {
  const db = readDb();
  const newProject = {
    ...req.body,
    id: req.body.id || `proj-${Date.now()}`,
  };
  db.projects.unshift(newProject);
  saveDb(db);
  res.status(201).json(newProject);
});

app.put('/api/projects/:id', (req, res) => {
  const db = readDb();
  const index = db.projects.findIndex((p) => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'Project not found' });
  }
  db.projects[index] = { ...db.projects[index], ...req.body };
  saveDb(db);
  res.json(db.projects[index]);
});

app.delete('/api/projects/:id', (req, res) => {
  const db = readDb();
  db.projects = db.projects.filter((p) => p.id !== req.params.id);
  saveDb(db);
  res.json({ success: true });
});

// Enquiries
app.post('/api/enquiries', (req, res) => {
  const db = readDb();
  const newEnquiry = {
    ...req.body,
    id: `enq-${Date.now()}`,
    createdAt: new Date().toISOString(),
    status: 'New' as const,
  };
  db.enquiries.unshift(newEnquiry);
  saveDb(db);
  res.status(201).json(newEnquiry);
});

app.patch('/api/enquiries/:id', (req, res) => {
  const db = readDb();
  const enquiry = db.enquiries.find((e) => e.id === req.params.id);
  if (!enquiry) {
    return res.status(404).json({ error: 'Enquiry not found' });
  }
  Object.assign(enquiry, req.body);
  saveDb(db);
  res.json(enquiry);
});

// Orders
app.post('/api/orders', (req, res) => {
  const db = readDb();
  const newOrder = {
    ...req.body,
    id: `ord-${Date.now()}`,
    createdAt: new Date().toISOString(),
    status: 'Pending',
  };
  db.orders.unshift(newOrder);
  saveDb(db);
  res.status(201).json(newOrder);
});

app.patch('/api/orders/:id', (req, res) => {
  const db = readDb();
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }
  Object.assign(order, req.body);
  saveDb(db);
  res.json(order);
});

// Settings
app.put('/api/settings', (req, res) => {
  const db = readDb();
  db.settings = { ...db.settings, ...req.body };
  saveDb(db);
  res.json(db.settings);
});

// Mount Vite middleware in dev or static files in production
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Divyanshi Nursery server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
